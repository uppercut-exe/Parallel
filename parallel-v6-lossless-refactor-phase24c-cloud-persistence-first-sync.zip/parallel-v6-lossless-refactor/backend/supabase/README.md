# Parallel — Supabase Backend Setup

**Phase 24A: Backend Architecture Readiness**

This folder contains everything needed to connect Parallel to a Supabase backend. The app runs fully in local mode without any of these steps — follow this guide only when you are ready to enable cloud sync.

---

## Prerequisites

- A [Supabase](https://supabase.com) account (free tier is sufficient for development)
- The Supabase CLI (optional, for CLI-based deployment)

---

## Step 1 — Create a Supabase Project

1. Go to [supabase.com](https://supabase.com) → New project
2. Choose a name (e.g. `parallel-workspace`)
3. Set a strong database password and save it
4. Wait for the project to provision (~1 minute)

---

## Step 2 — Apply the Schema

In your Supabase project:

**Dashboard method:**
1. Go to **SQL Editor** → **New Query**
2. Paste and run `schema.sql` (this file)
3. Paste and run `rls.sql`
4. Optionally paste and run `seed.sql` (demo data — replace placeholder UUIDs first)

**CLI method:**
```bash
# Install Supabase CLI
brew install supabase/tap/supabase

# Link to your project
supabase link --project-ref YOUR_PROJECT_REF

# Push schema
supabase db push
```

---

## Step 3 — Get Your Credentials

In the Supabase Dashboard:

1. Go to **Project Settings** → **API**
2. Copy:
   - **Project URL** — e.g. `https://xyzcompany.supabase.co`
   - **anon / public key** — the JWT anon key (safe to use client-side)

---

## Step 4 — Configure the App

In `systems/backend/backend-config.js`, replace the placeholder values:

```js
var _cfg = {
  url:     'https://YOUR_PROJECT_REF.supabase.co',
  anonKey: 'YOUR_ANON_KEY_HERE',
};
```

---

## Step 5 — Add the Supabase SDK

In `apps/app/index.html` and `apps/studio/index.html`, add this CDN script **before** the backend system scripts:

```html
<!-- Add before systems/backend/backend-config.js -->
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
```

The app will automatically detect the SDK and initialise the client.

---

## File Reference

| File | Purpose |
|---|---|
| `schema.sql` | Full database schema — all 13 tables, indexes, and triggers |
| `rls.sql` | Row Level Security policies for all tables |
| `seed.sql` | Demo workspace data matching the Phase 23 mock team |
| `README.md` | This file |

---

## Architecture Notes

### Local ↔ Cloud Identity

| Local | Supabase |
|---|---|
| `px_workspace_id` | `workspaces.id` |
| `px_v19_name` | `profiles.display_name` |
| `px_v19_mode` | `workspaces.mode` |
| Collaborator IDs (`collab-amara`, etc.) | `profiles.id` (UUID) |

On first cloud sync, a mapping table will translate local string IDs to Supabase UUIDs. This is handled by the Phase 24C migration flow.

### JSONB vs Relational

Properties that are flexible and workspace-specific use JSONB:
- `database_records.properties` — field values vary per database schema
- `databases.db_schema` — field definitions are user-configurable
- `pages.metadata` — lightweight metadata that doesn't warrant its own column
- `blocks.content` — block payload varies by block type

Core relations (workspace membership, record relations) use relational tables with proper foreign keys for query efficiency and referential integrity.

### Soft Delete Strategy

Tables with user-generated content use `deleted_at timestamptz` for soft deletes:
- `pages`, `blocks`, `databases`, `database_records`, `comments`, `assets`

Activity events (`activity_events`, `ai_outputs`) are append-only and never deleted.

---

## Phase Roadmap

| Phase | Feature |
|---|---|
| **24A** (current) | Schema design + client foundation (this phase) |
| **24B** | Auth + User Profile (Supabase Auth, session management) |
| **24C** | Cloud Save / Load (first real read/write from Supabase) |
| **24D** | Sync Queue + Conflict Handling (drain pendingOps[], version vectors) |
| **24E** | Realtime Collaboration (Supabase Realtime subscriptions) |

The app remains fully functional in local mode through all phases. Cloud features are additive.

---

## Storage Buckets

For file attachments (Phase 24C+), create a private Supabase Storage bucket:

```sql
-- Run in SQL Editor after creating the project
insert into storage.buckets (id, name, public)
values ('workspace-assets', 'workspace-assets', false);
```

RLS policies for storage are defined separately in the Supabase Dashboard under **Storage** → **Policies**.

---

## Security Notes

- The `anon` key is safe to use client-side — it is rate-limited and protected by Row Level Security
- Never expose the `service_role` key in client code
- All tables have RLS enabled — data is inaccessible without valid auth
- The `my_workspace_role()` helper function runs as `security definer` to bypass RLS internally while still checking membership
