-- ============================================================
-- Parallel Workspace — Seed Data
-- Phase 24A: Backend Architecture Readiness
--
-- Provides a demo workspace that mirrors the Phase 23 mock team
-- and seed content. Use this to bootstrap a fresh Supabase project
-- with realistic data for development and testing.
--
-- IMPORTANT:
--   auth.users rows are managed by Supabase Auth and cannot be
--   inserted directly via SQL. Follow these steps:
--     1. Create 5 users via the Supabase Auth API or Dashboard
--     2. Note the UUIDs assigned by Supabase
--     3. Replace the placeholder UUIDs below with the real ones
--     4. Run this seed file in the SQL Editor
--
-- Placeholder UUIDs used throughout (replace with real auth UUIDs):
--   Amara  — 00000000-0000-0000-0000-000000000001  (owner)
--   Kaia   — 00000000-0000-0000-0000-000000000002  (editor)
--   Jad    — 00000000-0000-0000-0000-000000000003  (editor)
--   Rami   — 00000000-0000-0000-0000-000000000004  (commenter)
--   Maya   — 00000000-0000-0000-0000-000000000005  (viewer)
-- ============================================================

-- ── Profiles (match Phase 23 collaborator mock team) ─────────────────

insert into public.profiles (id, display_name, email, role_default, color, is_local)
values
  ('00000000-0000-0000-0000-000000000001', 'Amara', 'amara@example.com',  'owner',     '{"bg":"#dde8de","color":"#4a6e50"}', false),
  ('00000000-0000-0000-0000-000000000002', 'Kaia',  'kaia@example.com',   'editor',    '{"bg":"#e8ddef","color":"#6e4a7c"}', false),
  ('00000000-0000-0000-0000-000000000003', 'Jad',   'jad@example.com',    'editor',    '{"bg":"#f5ede3","color":"#8a5c3c"}', false),
  ('00000000-0000-0000-0000-000000000004', 'Rami',  'rami@example.com',   'commenter', '{"bg":"#f3e8e8","color":"#8a4040"}', false),
  ('00000000-0000-0000-0000-000000000005', 'Maya',  'maya@example.com',   'viewer',    '{"bg":"#e3ecf5","color":"#3c5c8a"}', false)
on conflict (id) do nothing;

-- ── Workspace ────────────────────────────────────────────────────────

insert into public.workspaces (id, name, mode, owner_id, schema_version, settings, sync_enabled)
values (
  '00000000-0000-0000-0001-000000000001',
  'Amara''s Workspace',
  'agency',
  '00000000-0000-0000-0000-000000000001',
  2,
  '{
    "onboardingDone": true,
    "gettingStartedDismissed": false,
    "workspaceMode": "agency",
    "userName": "Amara",
    "syncEnabled": true,
    "capabilities": {
      "offlineSupport": true,
      "cloudSync": true,
      "collaboration": false,
      "versionHistory": false,
      "aiFeatures": true,
      "multiWorkspace": false
    }
  }',
  true
)
on conflict (id) do nothing;

-- ── Workspace members ─────────────────────────────────────────────────

insert into public.workspace_members (workspace_id, user_id, role)
values
  ('00000000-0000-0000-0001-000000000001', '00000000-0000-0000-0000-000000000001', 'owner'),
  ('00000000-0000-0000-0001-000000000001', '00000000-0000-0000-0000-000000000002', 'editor'),
  ('00000000-0000-0000-0001-000000000001', '00000000-0000-0000-0000-000000000003', 'editor'),
  ('00000000-0000-0000-0001-000000000001', '00000000-0000-0000-0000-000000000004', 'commenter'),
  ('00000000-0000-0000-0001-000000000001', '00000000-0000-0000-0000-000000000005', 'viewer')
on conflict (workspace_id, user_id) do nothing;

-- ── Databases ─────────────────────────────────────────────────────────

insert into public.databases (id, workspace_id, title, icon, description, template, db_schema, created_by, updated_by)
values
  (
    '00000000-0000-0000-0003-000000000001',
    '00000000-0000-0000-0001-000000000001',
    'Projects',
    'ti-briefcase',
    'Active project rooms across the workspace.',
    'projects',
    '[
      {"id":"f-status","name":"Status","type":"select","options":["Active","In Review","On Hold","Complete"]},
      {"id":"f-priority","name":"Priority","type":"select","options":["Critical","High","Normal","Low"]},
      {"id":"f-client","name":"Client","type":"text"},
      {"id":"f-timeline","name":"Timeline","type":"text"},
      {"id":"f-due","name":"Due Date","type":"date"},
      {"id":"f-progress","name":"Progress","type":"number"},
      {"id":"f-notes","name":"Notes","type":"text"}
    ]',
    '00000000-0000-0000-0000-000000000001',
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    '00000000-0000-0000-0003-000000000002',
    '00000000-0000-0000-0001-000000000001',
    'Clients',
    'ti-building-store',
    'Active client relationships and engagement history.',
    'clients',
    '[
      {"id":"f-status","name":"Status","type":"select","options":["Active","Prospect","Archived"]},
      {"id":"f-industry","name":"Industry","type":"text"},
      {"id":"f-contact","name":"Contact","type":"text"},
      {"id":"f-retainer","name":"Retainer","type":"text"},
      {"id":"f-notes","name":"Notes","type":"text"}
    ]',
    '00000000-0000-0000-0000-000000000001',
    '00000000-0000-0000-0000-000000000002'
  )
on conflict (id) do nothing;

-- ── Database records ──────────────────────────────────────────────────

insert into public.database_records (id, workspace_id, database_id, title, icon, properties, created_by, updated_by)
values
  (
    '00000000-0000-0000-0004-000000000001',
    '00000000-0000-0000-0001-000000000001',
    '00000000-0000-0000-0003-000000000001',
    'Lumena Brand Identity',
    'ti-sparkles',
    '{"Status":"Active","Priority":"High","Client":"Lumena Studio","Timeline":"Q2 2026","Progress":62,"Notes":"Brand system and visual identity"}',
    '00000000-0000-0000-0000-000000000001',
    '00000000-0000-0000-0000-000000000002'
  ),
  (
    '00000000-0000-0000-0004-000000000002',
    '00000000-0000-0000-0001-000000000001',
    '00000000-0000-0000-0003-000000000001',
    'Noura App MVP',
    'ti-device-mobile',
    '{"Status":"In Review","Priority":"Critical","Client":"Noura Health","Timeline":"Q3 2026","Progress":38,"Notes":"Mobile onboarding and core flows"}',
    '00000000-0000-0000-0000-000000000001',
    '00000000-0000-0000-0000-000000000003'
  ),
  (
    '00000000-0000-0000-0004-000000000003',
    '00000000-0000-0000-0001-000000000001',
    '00000000-0000-0000-0003-000000000001',
    'Wren Campaign Site',
    'ti-world',
    '{"Status":"Active","Priority":"Normal","Client":"Wren Editorial","Timeline":"Q2 2026","Progress":84,"Notes":"Campaign microsite — final polish"}',
    '00000000-0000-0000-0000-000000000001',
    '00000000-0000-0000-0000-000000000001'
  )
on conflict (id) do nothing;

-- ── Pages ─────────────────────────────────────────────────────────────

insert into public.pages (id, workspace_id, title, type, icon, metadata, created_by, updated_by, last_edited_by)
values
  (
    '00000000-0000-0000-0002-000000000001',
    '00000000-0000-0000-0001-000000000001',
    'Lumena Brand Brief',
    'doc',
    'ti-file-description',
    '{"section":"workspace","template":"brand"}',
    '00000000-0000-0000-0000-000000000001',
    '00000000-0000-0000-0000-000000000002',
    '00000000-0000-0000-0000-000000000002'
  ),
  (
    '00000000-0000-0000-0002-000000000002',
    '00000000-0000-0000-0001-000000000001',
    'Campaign Strategy Q3',
    'meeting',
    'ti-notes',
    '{"section":"workspace"}',
    '00000000-0000-0000-0000-000000000001',
    '00000000-0000-0000-0000-000000000001',
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    '00000000-0000-0000-0002-000000000003',
    '00000000-0000-0000-0001-000000000001',
    'Studio Overview',
    'doc',
    'ti-layout-dashboard',
    '{"section":"workspace"}',
    '00000000-0000-0000-0000-000000000001',
    '00000000-0000-0000-0000-000000000001',
    '00000000-0000-0000-0000-000000000001'
  )
on conflict (id) do nothing;

-- ── Comments ──────────────────────────────────────────────────────────

insert into public.comments (id, workspace_id, entity_type, entity_id, author_id, body, mentions)
values
  (
    '00000000-0000-0000-0005-000000000001',
    '00000000-0000-0000-0001-000000000001',
    'record',
    '00000000-0000-0000-0004-000000000001',
    '00000000-0000-0000-0000-000000000002',
    'Love the direction so far. The lilac is perfect — don''t soften it too much.',
    '[]'
  ),
  (
    '00000000-0000-0000-0005-000000000002',
    '00000000-0000-0000-0001-000000000001',
    'record',
    '00000000-0000-0000-0004-000000000001',
    '00000000-0000-0000-0000-000000000001',
    '@Kaia agreed — we''ll keep the lilac as the anchor and soften the secondary palette instead.',
    '["00000000-0000-0000-0000-000000000002"]'
  ),
  (
    '00000000-0000-0000-0005-000000000003',
    '00000000-0000-0000-0001-000000000001',
    'page',
    '00000000-0000-0000-0002-000000000001',
    '00000000-0000-0000-0000-000000000001',
    'This is the source of truth for the brand. @Kaia and @Rami please review before Thursday.',
    '["00000000-0000-0000-0000-000000000002","00000000-0000-0000-0000-000000000004"]'
  )
on conflict (id) do nothing;

-- ── Activity events ───────────────────────────────────────────────────

insert into public.activity_events (workspace_id, actor_id, event_type, entity_type, entity_id, entity_title, metadata)
values
  ('00000000-0000-0000-0001-000000000001', '00000000-0000-0000-0000-000000000001', 'workspace_setup',  'workspace', '00000000-0000-0000-0001-000000000001', 'Amara''s Workspace',  '{}'),
  ('00000000-0000-0000-0001-000000000001', '00000000-0000-0000-0000-000000000001', 'database_created', 'database',  '00000000-0000-0000-0003-000000000001', 'Projects',            '{}'),
  ('00000000-0000-0000-0001-000000000001', '00000000-0000-0000-0000-000000000001', 'database_created', 'database',  '00000000-0000-0000-0003-000000000002', 'Clients',             '{}'),
  ('00000000-0000-0000-0001-000000000001', '00000000-0000-0000-0000-000000000001', 'record_created',   'record',    '00000000-0000-0000-0004-000000000001', 'Lumena Brand Identity','{"databaseTitle":"Projects"}'),
  ('00000000-0000-0000-0001-000000000001', '00000000-0000-0000-0000-000000000003', 'record_created',   'record',    '00000000-0000-0000-0004-000000000002', 'Noura App MVP',        '{"databaseTitle":"Projects"}'),
  ('00000000-0000-0000-0001-000000000001', '00000000-0000-0000-0000-000000000001', 'page_created',     'page',      '00000000-0000-0000-0002-000000000001', 'Lumena Brand Brief',   '{}'),
  ('00000000-0000-0000-0001-000000000001', '00000000-0000-0000-0000-000000000002', 'page_updated',     'page',      '00000000-0000-0000-0002-000000000001', 'Lumena Brand Brief',   '{}'),
  ('00000000-0000-0000-0001-000000000001', '00000000-0000-0000-0000-000000000002', 'comment_added',    'record',    '00000000-0000-0000-0004-000000000001', 'Lumena Brand Identity','{}')
on conflict do nothing;
