-- ============================================================
-- Parallel Workspace — Supabase Database Schema
-- Phase 24A: Backend Architecture Readiness
--
-- Apply this schema to a new Supabase project via:
--   Dashboard > SQL Editor > New Query (paste and run)
--   OR: supabase db push (with Supabase CLI)
--
-- Table inventory:
--   profiles          — user identity metadata (extends auth.users)
--   workspaces        — workspace identity and settings
--   workspace_members — user ↔ workspace membership + roles
--   pages             — all page entities (doc, meeting, template, canvas)
--   blocks            — content blocks within pages and record pages
--   databases         — database definitions (schema, views, settings)
--   database_records  — individual records within databases
--   record_relations  — many-to-many links between records
--   comments          — threaded comments on records and pages
--   activity_events   — immutable workspace audit log
--   assets            — Supabase Storage file references
--   ai_outputs        — AI-generated content audit trail
--   sync_operations   — pending operation queue for offline-first sync
-- ============================================================

-- ── Extensions ────────────────────────────────────────────────────────

create extension if not exists "uuid-ossp";
create extension if not exists "pg_trgm";  -- for future full-text search

-- ── updated_at trigger function ───────────────────────────────────────

create or replace function public.handle_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- ============================================================
-- PROFILES
-- Extends auth.users with workspace-facing identity metadata.
-- One row per Supabase Auth user. Created automatically on first
-- sign-in via a Supabase Auth hook or manually on invite.
-- ============================================================

create table if not exists public.profiles (
  id            uuid        primary key references auth.users(id) on delete cascade,
  display_name  text        not null default '',
  email         text,
  avatar_url    text,
  role_default  text        not null default 'editor'
                              check (role_default in ('owner','editor','commenter','viewer')),
  color         jsonb       not null default '{}',   -- { bg, color } for initials avatar
  is_local      boolean     not null default false,  -- true = device-only identity pre-auth
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create trigger handle_profiles_updated_at
  before update on public.profiles
  for each row execute function public.handle_updated_at();

-- ============================================================
-- WORKSPACES
-- One logical workspace per team or individual.
-- Multi-workspace support (workspace switcher) is planned for
-- a future phase; for now each user has exactly one workspace.
-- ============================================================

create table if not exists public.workspaces (
  id              uuid        primary key default uuid_generate_v4(),
  name            text        not null default 'My Workspace',
  mode            text        not null default 'personal'
                                check (mode in ('agency','creator','product','personal')),
  owner_id        uuid        references public.profiles(id) on delete set null,
  schema_version  integer     not null default 2,
  settings        jsonb       not null default '{}',
  -- settings includes: { onboardingDone, gettingStartedDismissed,
  --   workspaceMode, userName, syncEnabled, capabilities{} }
  sync_enabled    boolean     not null default false,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  deleted_at      timestamptz            -- soft delete
);

create trigger handle_workspaces_updated_at
  before update on public.workspaces
  for each row execute function public.handle_updated_at();

create index if not exists idx_workspaces_owner on public.workspaces(owner_id);

-- ============================================================
-- WORKSPACE MEMBERS
-- Membership and role assignment for each user in a workspace.
-- ============================================================

create table if not exists public.workspace_members (
  id             uuid        primary key default uuid_generate_v4(),
  workspace_id   uuid        not null references public.workspaces(id) on delete cascade,
  user_id        uuid        not null references public.profiles(id) on delete cascade,
  role           text        not null default 'editor'
                               check (role in ('owner','editor','commenter','viewer')),
  joined_at      timestamptz not null default now(),
  last_active_at timestamptz,
  unique (workspace_id, user_id)
);

create index if not exists idx_workspace_members_workspace on public.workspace_members(workspace_id);
create index if not exists idx_workspace_members_user      on public.workspace_members(user_id);

-- ============================================================
-- PAGES
-- All page-type entities: docs, meeting notes, templates,
-- canvases, linked-database pages, and sub-pages.
-- Blocks are stored separately in the blocks table (FK: page_id).
-- ============================================================

create table if not exists public.pages (
  id              uuid        primary key default uuid_generate_v4(),
  workspace_id    uuid        not null references public.workspaces(id) on delete cascade,
  parent_id       uuid        references public.pages(id) on delete set null,
  title           text        not null default 'Untitled',
  type            text        not null default 'doc'
                                check (type in ('doc','meeting','template','canvas','linked-database','sub')),
  icon            text,                  -- tabler icon class e.g. 'ti-file'
  cover           text,                  -- cover image URL or gradient token
  sort_order      integer     not null default 0,
  archived        boolean     not null default false,
  metadata        jsonb       not null default '{}',
  -- metadata includes: { section, template, source, linkedDatabaseId, etc. }
  sharing_meta    jsonb       not null default '{}',
  -- sharing_meta: { isPublic, shareToken, permissionLevel, sharedWith[] }
  version         integer     not null default 1,
  created_by      uuid        references public.profiles(id) on delete set null,
  updated_by      uuid        references public.profiles(id) on delete set null,
  last_edited_by  uuid        references public.profiles(id) on delete set null,
  last_synced_at  timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  deleted_at      timestamptz
);

create trigger handle_pages_updated_at
  before update on public.pages
  for each row execute function public.handle_updated_at();

create index if not exists idx_pages_workspace on public.pages(workspace_id);
create index if not exists idx_pages_parent    on public.pages(parent_id) where parent_id is not null;
create index if not exists idx_pages_archived  on public.pages(workspace_id, archived);
create index if not exists idx_pages_type      on public.pages(workspace_id, type);

-- ============================================================
-- DATABASES
-- Database definitions: property schema, saved views, settings.
-- Individual records are stored in database_records.
-- ============================================================

create table if not exists public.databases (
  id              uuid        primary key default uuid_generate_v4(),
  workspace_id    uuid        not null references public.workspaces(id) on delete cascade,
  title           text        not null default 'Untitled Database',
  icon            text,
  description     text,
  db_schema       jsonb       not null default '[]',
  -- db_schema: array of { id, name, type, options[], required, width, ... }
  views           jsonb       not null default '[]',
  -- views: array of { id, name, type, groupBy, sortBy, filterBy, calendarField, ... }
  settings        jsonb       not null default '{}',
  -- settings: { template, defaultView, showCovers, density, etc. }
  template        text,       -- 'projects' | 'clients' | 'content' | 'meetings' | custom
  version         integer     not null default 1,
  archived        boolean     not null default false,
  created_by      uuid        references public.profiles(id) on delete set null,
  updated_by      uuid        references public.profiles(id) on delete set null,
  last_synced_at  timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  deleted_at      timestamptz
);

create trigger handle_databases_updated_at
  before update on public.databases
  for each row execute function public.handle_updated_at();

create index if not exists idx_databases_workspace on public.databases(workspace_id);
create index if not exists idx_databases_template  on public.databases(workspace_id, template);

-- ============================================================
-- DATABASE RECORDS
-- Individual records (rows) within a database.
-- Properties are stored as flexible JSONB keyed by field name.
-- The record page body blocks may be stored inline in `blocks`
-- or via FK to the blocks table (record_id).
-- ============================================================

create table if not exists public.database_records (
  id              uuid        primary key default uuid_generate_v4(),
  workspace_id    uuid        not null references public.workspaces(id) on delete cascade,
  database_id     uuid        not null references public.databases(id) on delete cascade,
  title           text        not null default 'Untitled',
  icon            text,
  properties      jsonb       not null default '{}',
  -- properties: { "Status": "Active", "Priority": "High", "DueDate": "2026-06-01", ... }
  -- field names match db_schema[].name on the parent database
  blocks          jsonb       not null default '[]',
  -- blocks: inline block array for the record page body
  -- large records may migrate these to the blocks table (FK record_id) in Phase 24C+
  metadata        jsonb       not null default '{}',
  -- metadata: { source, tags, aiMeta: { hasSummary, lastSummaryAt }, etc. }
  sharing_meta    jsonb       not null default '{}',
  archived        boolean     not null default false,
  version         integer     not null default 1,
  created_by      uuid        references public.profiles(id) on delete set null,
  updated_by      uuid        references public.profiles(id) on delete set null,
  last_edited_by  uuid        references public.profiles(id) on delete set null,
  last_synced_at  timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  deleted_at      timestamptz
);

create trigger handle_records_updated_at
  before update on public.database_records
  for each row execute function public.handle_updated_at();

create index if not exists idx_records_database  on public.database_records(database_id);
create index if not exists idx_records_workspace on public.database_records(workspace_id);
create index if not exists idx_records_archived  on public.database_records(database_id, archived);

-- ============================================================
-- BLOCKS
-- Content blocks inside page bodies and record page bodies.
-- Supports nested blocks via parent_block_id.
-- page_id  — set when block belongs to a page
-- record_id — set when block belongs to a record page
-- Exactly one of page_id / record_id should be non-null per block.
-- ============================================================

create table if not exists public.blocks (
  id              uuid        primary key default uuid_generate_v4(),
  workspace_id    uuid        not null references public.workspaces(id) on delete cascade,
  page_id         uuid        references public.pages(id) on delete cascade,
  record_id       uuid        references public.database_records(id) on delete cascade,
  parent_block_id uuid        references public.blocks(id) on delete cascade,
  type            text        not null default 'p'
                                check (type in (
                                  'p','h1','h2','h3','bullet','numbered','todo',
                                  'callout','quote','code','divider','image',
                                  'link-preview','embed','columns','table',
                                  'database','linked-database'
                                )),
  content         jsonb       not null default '{}',
  -- content varies by type:
  --   p/h1/h2/h3/bullet/numbered/quote: { text }
  --   todo:        { text, checked }
  --   callout:     { text, icon, color }
  --   code:        { text, language }
  --   image:       { url, alt, caption }
  --   link-preview: { url, title, description, image }
  --   database:    { databaseId }
  --   linked-database: { databaseId, viewId, filter }
  sort_order      integer     not null default 0,
  version         integer     not null default 1,
  created_by      uuid        references public.profiles(id) on delete set null,
  updated_by      uuid        references public.profiles(id) on delete set null,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  deleted_at      timestamptz,
  constraint blocks_one_parent check (
    (page_id is not null)::integer + (record_id is not null)::integer <= 1
  )
);

create trigger handle_blocks_updated_at
  before update on public.blocks
  for each row execute function public.handle_updated_at();

create index if not exists idx_blocks_page      on public.blocks(page_id)   where page_id   is not null;
create index if not exists idx_blocks_record    on public.blocks(record_id) where record_id is not null;
create index if not exists idx_blocks_workspace on public.blocks(workspace_id);
create index if not exists idx_blocks_parent    on public.blocks(parent_block_id) where parent_block_id is not null;

-- ============================================================
-- RECORD RELATIONS
-- Many-to-many links between records across databases.
-- Mirrors the relation field type in the database schema.
-- ============================================================

create table if not exists public.record_relations (
  id                uuid        primary key default uuid_generate_v4(),
  workspace_id      uuid        not null references public.workspaces(id) on delete cascade,
  source_record_id  uuid        not null references public.database_records(id) on delete cascade,
  target_record_id  uuid        not null references public.database_records(id) on delete cascade,
  relation_field_id text        not null,  -- field name on the source record's database schema
  relation_type     text        not null default 'linked'
                                  check (relation_type in ('linked','rollup','formula')),
  created_by        uuid        references public.profiles(id) on delete set null,
  created_at        timestamptz not null default now(),
  unique (source_record_id, target_record_id, relation_field_id)
);

create index if not exists idx_relations_source on public.record_relations(source_record_id);
create index if not exists idx_relations_target on public.record_relations(target_record_id);
create index if not exists idx_relations_ws     on public.record_relations(workspace_id);

-- ============================================================
-- COMMENTS
-- Threaded comments on records and pages.
-- parent_id enables reply threading (Phase 25+).
-- resolved_at replaces the boolean `resolved` flag from localStorage.
-- ============================================================

create table if not exists public.comments (
  id           uuid        primary key default uuid_generate_v4(),
  workspace_id uuid        not null references public.workspaces(id) on delete cascade,
  entity_type  text        not null check (entity_type in ('record','page')),
  entity_id    uuid        not null,
  parent_id    uuid        references public.comments(id) on delete cascade,
  author_id    uuid        references public.profiles(id) on delete set null,
  body         text        not null default '',
  mentions     jsonb       not null default '[]',  -- array of profile IDs mentioned
  resolved_at  timestamptz,                         -- null = active; timestamp = resolved
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  deleted_at   timestamptz
);

create trigger handle_comments_updated_at
  before update on public.comments
  for each row execute function public.handle_updated_at();

create index if not exists idx_comments_entity   on public.comments(entity_type, entity_id);
create index if not exists idx_comments_workspace on public.comments(workspace_id);
create index if not exists idx_comments_active    on public.comments(workspace_id, resolved_at) where resolved_at is null;
create index if not exists idx_comments_parent    on public.comments(parent_id) where parent_id is not null;

-- ============================================================
-- ACTIVITY EVENTS
-- Immutable workspace audit log. One row per meaningful action.
-- Events are append-only: no update or delete (except by admin).
-- Mirrors the localStorage px_activity_v1 store.
-- ============================================================

create table if not exists public.activity_events (
  id           uuid        primary key default uuid_generate_v4(),
  workspace_id uuid        not null references public.workspaces(id) on delete cascade,
  actor_id     uuid        references public.profiles(id) on delete set null,
  event_type   text        not null,
  -- event_type constants (mirrors ParallelActivity.TYPES):
  --   page_created, page_updated, page_archived
  --   record_created, record_updated, record_archived, status_changed
  --   comment_added, relation_added, database_created
  --   ai_summary, date_changed, workspace_setup
  entity_type  text        not null check (entity_type in ('page','record','database','comment','workspace')),
  entity_id    uuid        not null,
  entity_title text,
  database_id  uuid        references public.databases(id) on delete set null,
  metadata     jsonb       not null default '{}',
  -- metadata is type-specific: e.g. { statusFrom, statusTo } for status_changed
  created_at   timestamptz not null default now()
  -- no updated_at — events are immutable
  -- no deleted_at — audit log is permanent (admins can purge via separate policy)
);

create index if not exists idx_activity_workspace on public.activity_events(workspace_id);
create index if not exists idx_activity_entity    on public.activity_events(entity_type, entity_id);
create index if not exists idx_activity_actor     on public.activity_events(actor_id);
create index if not exists idx_activity_recent    on public.activity_events(workspace_id, created_at desc);

-- ============================================================
-- ASSETS
-- References to files stored in Supabase Storage.
-- The actual bytes live in a Storage bucket; this table holds
-- metadata and the storage path used to generate signed URLs.
-- ============================================================

create table if not exists public.assets (
  id            uuid        primary key default uuid_generate_v4(),
  workspace_id  uuid        not null references public.workspaces(id) on delete cascade,
  owner_id      uuid        references public.profiles(id) on delete set null,
  storage_path  text        not null,   -- path within the Supabase Storage bucket
  bucket        text        not null default 'workspace-assets',
  file_name     text        not null,
  mime_type     text,
  file_size     bigint,
  metadata      jsonb       not null default '{}',
  -- metadata: { alt, caption, width, height, source_url, entity_type, entity_id }
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  deleted_at    timestamptz
);

create trigger handle_assets_updated_at
  before update on public.assets
  for each row execute function public.handle_updated_at();

create index if not exists idx_assets_workspace on public.assets(workspace_id);
create index if not exists idx_assets_owner     on public.assets(owner_id);

-- ============================================================
-- AI OUTPUTS
-- Audit trail of AI-generated content (summaries, next steps,
-- breakdowns, meeting agendas). Append-only like activity_events.
-- Enables caching and surfacing prior AI responses in the UI.
-- ============================================================

create table if not exists public.ai_outputs (
  id           uuid        primary key default uuid_generate_v4(),
  workspace_id uuid        not null references public.workspaces(id) on delete cascade,
  entity_type  text        not null check (entity_type in ('record','page')),
  entity_id    uuid        not null,
  action_type  text        not null,
  -- action_type: 'summarize' | 'next_steps' | 'break_down' | 'agenda'
  input_hash   text,        -- SHA-256 of the input context (future: dedup identical requests)
  output_text  text        not null,
  model        text,        -- model identifier used to generate this output
  actor_id     uuid        references public.profiles(id) on delete set null,
  created_at   timestamptz not null default now()
);

create index if not exists idx_ai_outputs_entity    on public.ai_outputs(entity_type, entity_id);
create index if not exists idx_ai_outputs_workspace on public.ai_outputs(workspace_id);

-- ============================================================
-- SYNC OPERATIONS
-- Pending operation queue for offline-first sync (Phase 24D+).
-- The local client appends ops here; the sync worker drains them
-- in order, applying them to the canonical backend state.
-- Conflicts are detected by comparing version numbers.
-- ============================================================

create table if not exists public.sync_operations (
  id              uuid        primary key default uuid_generate_v4(),
  workspace_id    uuid        not null references public.workspaces(id) on delete cascade,
  client_id       text        not null,   -- stable device identifier
  operation_type  text        not null    check (operation_type in ('create','update','delete','relate','unrelate')),
  entity_type     text        not null    check (entity_type in ('page','block','database','record','comment','asset')),
  entity_id       uuid        not null,
  base_version    integer,               -- entity version the client had when queuing this op
  payload         jsonb       not null default '{}',  -- the delta to apply
  applied_at      timestamptz,           -- null = pending; timestamp = applied server-side
  conflict_info   jsonb,                 -- non-null when a conflict was detected
  created_at      timestamptz not null default now()
);

create index if not exists idx_sync_ops_workspace on public.sync_operations(workspace_id);
create index if not exists idx_sync_ops_pending   on public.sync_operations(workspace_id, applied_at) where applied_at is null;
create index if not exists idx_sync_ops_client    on public.sync_operations(workspace_id, client_id);
