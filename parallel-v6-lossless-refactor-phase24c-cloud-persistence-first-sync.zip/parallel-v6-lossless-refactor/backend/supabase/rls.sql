-- ============================================================
-- Parallel Workspace — Row Level Security Policies
-- Phase 24A: Backend Architecture Readiness
--
-- Apply AFTER schema.sql.
-- These policies ensure users can only access data in workspaces
-- they belong to, with role-based write restrictions.
--
-- Role model:
--   owner     — full control, can manage members, delete workspace
--   editor    — create, read, update, soft-delete content
--   commenter — read content, add/edit own comments
--   viewer    — read only
--
-- Soft delete:
--   Rows with deleted_at IS NOT NULL are excluded from SELECT
--   policies. Hard deletion is reserved for workspace owners
--   or cascades from parent row deletion.
-- ============================================================

-- ── Enable RLS on all tables ──────────────────────────────────────────

alter table public.profiles          enable row level security;
alter table public.workspaces        enable row level security;
alter table public.workspace_members enable row level security;
alter table public.pages             enable row level security;
alter table public.blocks            enable row level security;
alter table public.databases         enable row level security;
alter table public.database_records  enable row level security;
alter table public.record_relations  enable row level security;
alter table public.comments          enable row level security;
alter table public.activity_events   enable row level security;
alter table public.assets            enable row level security;
alter table public.ai_outputs        enable row level security;
alter table public.sync_operations   enable row level security;

-- ── Helper functions ──────────────────────────────────────────────────
-- These run as security definer so they can bypass RLS internally.
-- All functions are stable (same inputs = same output within a query).

create or replace function public.my_workspace_role(ws_id uuid)
returns text language sql security definer stable as $$
  select role from public.workspace_members
  where workspace_id = ws_id and user_id = auth.uid()
  limit 1;
$$;

create or replace function public.is_workspace_member(ws_id uuid)
returns boolean language sql security definer stable as $$
  select exists (
    select 1 from public.workspace_members
    where workspace_id = ws_id and user_id = auth.uid()
  );
$$;

create or replace function public.can_edit_workspace(ws_id uuid)
returns boolean language sql security definer stable as $$
  select exists (
    select 1 from public.workspace_members
    where workspace_id = ws_id
      and user_id = auth.uid()
      and role in ('owner','editor')
  );
$$;

create or replace function public.can_comment_workspace(ws_id uuid)
returns boolean language sql security definer stable as $$
  select exists (
    select 1 from public.workspace_members
    where workspace_id = ws_id
      and user_id = auth.uid()
      and role in ('owner','editor','commenter')
  );
$$;

-- ── PROFILES ────────────────────────────────────────────────────────

-- Users can always read their own profile
create policy "profiles_select_own"
  on public.profiles for select
  using (id = auth.uid());

-- Users can read profiles of teammates (anyone sharing a workspace)
create policy "profiles_select_teammates"
  on public.profiles for select
  using (
    exists (
      select 1
      from public.workspace_members wm1
      join public.workspace_members wm2 on wm1.workspace_id = wm2.workspace_id
      where wm1.user_id = auth.uid()
        and wm2.user_id = profiles.id
    )
  );

-- Users can only update their own profile
create policy "profiles_update_own"
  on public.profiles for update
  using (id = auth.uid());

-- ── WORKSPACES ──────────────────────────────────────────────────────

create policy "workspaces_select_member"
  on public.workspaces for select
  using (is_workspace_member(id) and deleted_at is null);

create policy "workspaces_insert_owner"
  on public.workspaces for insert
  with check (owner_id = auth.uid());

create policy "workspaces_update_owner"
  on public.workspaces for update
  using (owner_id = auth.uid());

create policy "workspaces_soft_delete_owner"
  on public.workspaces for update
  using (owner_id = auth.uid());

-- ── WORKSPACE MEMBERS ───────────────────────────────────────────────

-- All workspace members can see who else is in the workspace
create policy "workspace_members_select"
  on public.workspace_members for select
  using (is_workspace_member(workspace_id));

-- Only owners can add, change, or remove members
create policy "workspace_members_insert_owner"
  on public.workspace_members for insert
  with check (my_workspace_role(workspace_id) = 'owner');

create policy "workspace_members_update_owner"
  on public.workspace_members for update
  using (my_workspace_role(workspace_id) = 'owner');

create policy "workspace_members_delete_owner"
  on public.workspace_members for delete
  using (my_workspace_role(workspace_id) = 'owner');

-- ── PAGES ───────────────────────────────────────────────────────────

-- All members can read non-deleted pages
create policy "pages_select_member"
  on public.pages for select
  using (is_workspace_member(workspace_id) and deleted_at is null);

-- Editors and owners can create pages
create policy "pages_insert_editor"
  on public.pages for insert
  with check (can_edit_workspace(workspace_id));

-- Editors and owners can update pages (including archiving)
create policy "pages_update_editor"
  on public.pages for update
  using (can_edit_workspace(workspace_id));

-- Soft delete: same as update, handled via deleted_at
-- Hard delete: owners only
create policy "pages_hard_delete_owner"
  on public.pages for delete
  using (my_workspace_role(workspace_id) = 'owner');

-- ── BLOCKS ──────────────────────────────────────────────────────────

create policy "blocks_select_member"
  on public.blocks for select
  using (is_workspace_member(workspace_id) and deleted_at is null);

create policy "blocks_insert_editor"
  on public.blocks for insert
  with check (can_edit_workspace(workspace_id));

create policy "blocks_update_editor"
  on public.blocks for update
  using (can_edit_workspace(workspace_id));

create policy "blocks_delete_editor"
  on public.blocks for delete
  using (can_edit_workspace(workspace_id));

-- ── DATABASES ───────────────────────────────────────────────────────

create policy "databases_select_member"
  on public.databases for select
  using (is_workspace_member(workspace_id) and deleted_at is null);

create policy "databases_insert_editor"
  on public.databases for insert
  with check (can_edit_workspace(workspace_id));

create policy "databases_update_editor"
  on public.databases for update
  using (can_edit_workspace(workspace_id));

create policy "databases_hard_delete_owner"
  on public.databases for delete
  using (my_workspace_role(workspace_id) = 'owner');

-- ── DATABASE RECORDS ────────────────────────────────────────────────

create policy "records_select_member"
  on public.database_records for select
  using (is_workspace_member(workspace_id) and deleted_at is null);

create policy "records_insert_editor"
  on public.database_records for insert
  with check (can_edit_workspace(workspace_id));

create policy "records_update_editor"
  on public.database_records for update
  using (can_edit_workspace(workspace_id));

create policy "records_hard_delete_owner"
  on public.database_records for delete
  using (my_workspace_role(workspace_id) = 'owner');

-- ── RECORD RELATIONS ────────────────────────────────────────────────

create policy "relations_select_member"
  on public.record_relations for select
  using (is_workspace_member(workspace_id));

create policy "relations_insert_editor"
  on public.record_relations for insert
  with check (can_edit_workspace(workspace_id));

create policy "relations_delete_editor"
  on public.record_relations for delete
  using (can_edit_workspace(workspace_id));

-- ── COMMENTS ────────────────────────────────────────────────────────

-- Commenters and above can read all active (non-deleted) comments
create policy "comments_select_member"
  on public.comments for select
  using (is_workspace_member(workspace_id) and deleted_at is null);

-- Commenters, editors, and owners can add comments
create policy "comments_insert_commenter"
  on public.comments for insert
  with check (can_comment_workspace(workspace_id));

-- Authors can edit their own comment body
create policy "comments_update_author"
  on public.comments for update
  using (author_id = auth.uid());

-- Editors and owners can resolve or soft-delete any comment
create policy "comments_resolve_editor"
  on public.comments for update
  using (can_edit_workspace(workspace_id));

-- Authors can delete their own; owners can delete any
create policy "comments_delete_author_or_owner"
  on public.comments for delete
  using (
    author_id = auth.uid()
    or my_workspace_role(workspace_id) = 'owner'
  );

-- ── ACTIVITY EVENTS ─────────────────────────────────────────────────

-- All workspace members can read the activity feed
create policy "activity_select_member"
  on public.activity_events for select
  using (is_workspace_member(workspace_id));

-- Any workspace member can append events
create policy "activity_insert_member"
  on public.activity_events for insert
  with check (is_workspace_member(workspace_id));

-- Activity events are immutable — no update or delete policies
-- (Workspace owners may purge via a privileged server-side function in Phase 24D+)

-- ── ASSETS ──────────────────────────────────────────────────────────

create policy "assets_select_member"
  on public.assets for select
  using (is_workspace_member(workspace_id) and deleted_at is null);

create policy "assets_insert_editor"
  on public.assets for insert
  with check (can_edit_workspace(workspace_id));

-- Owners of the asset or workspace owners can update metadata
create policy "assets_update_owner"
  on public.assets for update
  using (owner_id = auth.uid() or my_workspace_role(workspace_id) = 'owner');

-- Owners of the asset or workspace owners can delete
create policy "assets_delete_owner"
  on public.assets for delete
  using (owner_id = auth.uid() or my_workspace_role(workspace_id) = 'owner');

-- ── AI OUTPUTS ──────────────────────────────────────────────────────

-- All workspace members can read AI outputs (for future caching/display)
create policy "ai_outputs_select_member"
  on public.ai_outputs for select
  using (is_workspace_member(workspace_id));

-- Any workspace member can append AI outputs
create policy "ai_outputs_insert_member"
  on public.ai_outputs for insert
  with check (is_workspace_member(workspace_id));

-- AI outputs are append-only (no update/delete policies)

-- ── SYNC OPERATIONS ─────────────────────────────────────────────────

-- Clients can read their own workspace's sync ops
create policy "sync_ops_select_member"
  on public.sync_operations for select
  using (is_workspace_member(workspace_id));

-- Any workspace member can enqueue sync ops
create policy "sync_ops_insert_member"
  on public.sync_operations for insert
  with check (is_workspace_member(workspace_id));

-- The sync worker (service role) marks ops as applied via server function.
-- Client-side update is intentionally restricted to prevent manipulation.
create policy "sync_ops_update_service"
  on public.sync_operations for update
  using (is_workspace_member(workspace_id));
