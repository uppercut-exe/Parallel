# Phase 24C: Cloud Persistence + First Sync

## Summary

Phase 24C adds the first real cloud save and cloud load to Parallel. When a user is signed in via Supabase, they can upload their entire local workspace to the cloud and download it back on any device — with full safety guarantees: a local backup is always created before any cloud load, no data is ever silently overwritten, and local mode continues to work without any cloud interaction.

---

## Part 1 — Cloud Persistence Module

### New file: `systems/backend/cloud-persistence.js`

Safe, one-shot upload and download of all workspace data. Exports `ParallelCloud` to `window`.

**Public API:**

| Method / Property | Type | Description |
|---|---|---|
| `getIdMap()` | object | Reads `px_cloud_id_map_v1` (local IDs → Supabase UUIDs) |
| `saveIdMap(map)` | void | Persists the ID map |
| `getSyncStatus()` | object | Reads `px_cloud_sync_v1` (last upload/download timestamps + error) |
| `updateSyncStatus(patch)` | void | Patches and persists sync status |
| `createLocalBackup()` | boolean | Saves `px_local_backup_v1` before any cloudLoad |
| `resolveUserId(localCollabId)` | string\|null | Maps local `collab-*` ID → Supabase auth UUID |
| `emitProgress(step, total, label, status)` | void | Dispatches `parallelCloudProgress` CustomEvent |
| `cloudSave()` | Promise | Sequential upload of all workspace data |
| `cloudLoad()` | Promise | Fetch from cloud → backup → hydrate → reload |
| `hydrateFromCloud(cloudData)` | void | Converts cloud rows back to local format |

**Entity upload order (foreign-key safe):**
1. Workspace metadata
2. Databases
3. Records (per database)
4. Pages (roots first, then children)
5. Comments
6. Activity events

---

## Part 2 — ID Mapping Strategy

### localStorage key: `px_cloud_id_map_v1`

```json
{
  "pages":     { "pg-brand-brief": "uuid-…", "pg-sprint-board": "uuid-…" },
  "databases": { "db-projects": "uuid-…", "db-content": "uuid-…" },
  "records":   { "rec-project-lumena": "uuid-…" },
  "comments":  { "comment-1": "uuid-…" },
  "activity":  { "act-1": "uuid-…" }
}
```

On first upload: Supabase generates UUIDs; they are stored in this map.
On repeat upload: UPDATE WHERE id = cloudUuid (idempotent; safe to re-run).
On cloud load: reverse map is built (cloudUUID → localId) to restore local IDs.

---

## Part 3 — Block Storage Strategy (Phase 24C)

| Content type | Storage approach |
|---|---|
| Page blocks | `pages.metadata.blocks` JSONB (inline in the pages table) |
| Record blocks | `database_records.blocks` JSONB (existing column) |

The separate `public.blocks` table in the schema is reserved for Phase 24D, which will normalize blocks into proper rows for richer querying and block-level sync.

---

## Part 4 — Local Backup Safety

### localStorage key: `px_local_backup_v1`

```json
{
  "workspace":  { … full parallel.studio.phase4.v2 snapshot … },
  "comments":   [ … ],
  "activity":   [ … ],
  "backedUpAt": "2026-05-21T18:00:00.000Z"
}
```

Created immediately before every `cloudLoad()` call. Never created by `cloudSave()`. Never auto-deleted. Users can restore manually from DevTools if needed.

---

## Part 5 — Sync Status

### localStorage key: `px_cloud_sync_v1`

```json
{
  "lastUploadAt":   "2026-05-21T18:00:00.000Z",
  "lastDownloadAt": null,
  "uploadCount":    1,
  "downloadCount":  0,
  "lastError":      null
}
```

Displayed in the cloud control panel inside the auth sheet. "Last error" replaces "Last saved" when the most recent operation failed.

---

## Part 6 — Cloud Control UI

### Cloud panel (replaces the Phase 24B "signed-in" view)

When a user is signed in, tapping the backend status chip opens the auth sheet and shows the cloud control panel instead of the Phase 24B message.

**Panel sections:**
- User avatar + name + email + "Cloud identity connected" badge
- Sync status row: "Last saved" timestamp or error message
- Progress bar area (appears during active upload/download)
- Action row: **Save to cloud** (primary) + **Load from cloud** (secondary)
- Safety note: "Your local workspace is always kept. Cloud save does not delete local data."
- Divider
- "This is a one-way snapshot sync. Realtime collaboration is coming in a future update." note
- Sign out button

**Load from cloud confirmation overlay:**

Tapping "Load from cloud" inserts a full-height confirmation overlay inside the auth sheet (not a modal) showing:
- Warning icon
- "Load from cloud?" title
- "Your local workspace will be replaced…" body
- Cancel + Yes, load buttons

This overlay is cancellable at any time before confirming.

**Progress bar:**
- `parallelCloudProgress` event updates a 4px height progress bar
- Label shows current step ("Saving databases…", "Upload complete", etc.)
- Icon changes: loader (running) → check (done) → alert (error)
- Buttons are disabled while `_cloudBusy` is true

**Override pattern:**
Phase 24C's JS block wraps `window.renderAuthContent` at init time:

```js
(function(){
  var _orig = window.renderAuthContent;
  window.renderAuthContent = function(){
    if (auth.authMode === 'signed-in') {
      inner.innerHTML = renderCloudPanel(auth);
    } else {
      _orig && _orig();
    }
  };
})();
```

This avoids modifying Phase 24B's code directly. The original function is preserved and called for all non-signed-in states.

---

## Part 7 — User ID Resolution

```js
resolveUserId(localCollabId)
```

1. Looks up `localCollabId` (e.g. `'collab-amara'`) in `px_collab_id_map_v1`
2. If found: returns the Supabase auth UUID
3. If not found: returns the currently signed-in user's UUID (`ParallelAuth.user.id`)
4. If no user: returns `null`

Unknown collaborators (Kaia, Jad, Rami, Maya) fall back to the current user's UUID when uploading `createdBy`/`updatedBy`. This is intentional — mock collaborators do not have real Supabase accounts. Phase 24D adds a team-invite flow that resolves real UUIDs for all workspace members.

---

## Part 8 — Preservation + Regression Audit

### All Phase 1–24B features confirmed intact

| System | Status |
|---|---|
| Global shell — one footer, one plus button, dock order | ✅ |
| Studio Command Center (all sections) | ✅ |
| Onboarding Phase 19 | ✅ |
| Ask Parallel AI sheet Phase 20 | ✅ |
| AI Actions on records | ✅ |
| All 6 database views + Grouped List | ✅ |
| Record editor: properties, relations, rollups, formulas, block body | ✅ |
| Phase 23 collaboration: comments, activity, avatars, attributions | ✅ |
| Phase 24A backend config + status chip | ✅ |
| Phase 24B auth sheet + sign-in/sign-up + identity | ✅ |
| App opens with no Supabase credentials — full local mode | ✅ |
| Auth sheet does not open automatically | ✅ |
| Auth sheet dismissible — local mode continues | ✅ |
| Cloud panel only shown when signed in | ✅ |
| cloudSave() never runs in local mode | ✅ |
| cloudLoad() creates backup before hydrating | ✅ |
| No data migrated or wiped by Phase 24C alone | ✅ |
| All existing localStorage keys unchanged | ✅ |
| Legacy files byte-for-byte identical | ✅ |

### localStorage safety audit

| Key | Phase | Phase 24C change |
|---|---|---|
| `parallel.studio.phase4.v2` | Phase 4 | Read by cloudSave(); written by hydrateFromCloud() after cloudLoad() |
| `px_schema_version` | Phase 22 | Unchanged |
| `px_workspace_id` | Phase 22 | Unchanged |
| `px_workspace_name` | Phase 22 | Read only |
| `px_v19_*` | Phase 19 | Unchanged — only read |
| `px_activity_v1` | Phase 23 | Read by cloudSave(); written by hydrateFromCloud() |
| `px_comments_v1` | Phase 23 | Read by cloudSave(); written by hydrateFromCloud() |
| `px_auth_identity_v1` | Phase 24B | Unchanged |
| `px_collab_id_map_v1` | Phase 24B | Read by resolveUserId() |
| `px_cloud_id_map_v1` | **Phase 24C** | New — local ID → Supabase UUID mapping |
| `px_cloud_sync_v1` | **Phase 24C** | New — last upload/download timestamps + error |
| `px_local_backup_v1` | **Phase 24C** | New — pre-load backup (workspace + comments + activity) |

---

## Files Added / Changed

| File | Type | Description |
|---|---|---|
| `systems/backend/cloud-persistence.js` | New | ParallelCloud module — cloudSave, cloudLoad, hydrateFromCloud, ID mapping |
| `apps/app/index.html` | Modified | cloud-persistence.js script tag, Phase 24C CSS, cloud control JS, initCloudSystem call |
| `apps/studio/index.html` | Modified | Same changes mirrored (defensive `if(window.initCloudSystem)` guard) |
| `docs/PHASE24C_CLOUD_PERSISTENCE_FIRST_SYNC.md` | New | This file |
| `README.md` | Modified | Phase 24C entry added |

---

## Remaining Deferred Work

1. **Block normalization** — Page blocks stored in `pages.metadata.blocks` JSONB for now. Phase 24D will normalize to the proper `public.blocks` table for block-level sync and querying.

2. **Incremental sync / dirty-flag queue** — Phase 24C is a full snapshot upload. Phase 24D adds a dirty-flag queue so only changed entities are re-uploaded.

3. **Conflict resolution** — Phase 24C's cloudLoad replaces local data wholesale. Phase 24F adds field-level merge and conflict detection.

4. **Mock collaborator identity** — Kaia, Jad, Rami, Maya `createdBy`/`updatedBy` fall back to current user UUID when uploading. Phase 24D's team-invite flow will resolve real UUIDs.

5. **Asset / file upload** — `avatar_url`, page covers, and record attachments are not uploaded in Phase 24C. Phase 24G adds Supabase Storage integration.

6. **Realtime subscriptions** — Phase 24E adds `supabase.channel()` subscriptions for live multi-device updates.

7. **Automatic sync** — Phase 24C is manual (user taps Save / Load). Phase 24D adds configurable auto-save on change.
