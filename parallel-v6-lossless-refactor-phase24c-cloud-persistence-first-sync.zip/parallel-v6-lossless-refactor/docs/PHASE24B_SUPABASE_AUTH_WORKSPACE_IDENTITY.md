# Phase 24B: Supabase Auth + Workspace Identity

## Summary

Phase 24B introduces real user identity into Parallel. The app gains Supabase Auth readiness, a calm auth sheet UI, profile and workspace ownership architecture, local-to-cloud identity mapping, and session state display — while remaining **fully usable in local mode at all times**. No login wall was added. No data was migrated. No localStorage keys were removed.

---

## Part 1 — Supabase Auth Integration

### New file: `systems/backend/auth.js`

Safe wrapper around Supabase Auth. Exports `ParallelAuth` to `window`.

**Auth modes:**

| Mode | When |
|---|---|
| `'local'` | Supabase not configured (no credentials in backend-config.js) |
| `'signed-out'` | Supabase configured; no active session |
| `'signed-in'` | Active Supabase session |

**Public API:**

| Property / Method | Type | Description |
|---|---|---|
| `isReady` | boolean | True when Supabase client is active |
| `isSignedIn` | boolean | True when session exists or cached identity is present |
| `authMode` | string | `'local'` \| `'signed-out'` \| `'signed-in'` |
| `displayName` | string | Resolved from profile → user metadata → `px_v19_name` → `'User'` |
| `statusLabel` | string | `'Local workspace'` \| `'Cloud ready'` \| `'Signed in'` |
| `user` | User\|null | Raw Supabase User object |
| `session` | Session\|null | Raw Supabase Session object |
| `profile` | Row\|null | Loaded `public.profiles` row |
| `supabaseWorkspaceId` | string\|null | UUID of the cloud workspace (null until created) |
| `collabIdMap` | object | Local `collab-*` IDs → Supabase auth UUIDs |
| `getCachedIdentity()` | object\|null | Reads `px_auth_identity_v1` |
| `initialize()` | void | Subscribe to auth state; restore existing session |
| `signIn(email, pwd)` | Promise | Sign in with email + password |
| `signUp(email, pwd, name)` | Promise | Create account with email + password + name |
| `signOut()` | Promise | Sign out; clears cached identity |
| `getSession()` | Promise | Current session |
| `getUser()` | Promise | Current user |
| `onAuthStateChange(fn)` | void | Subscribe to auth events |
| `createOrLoadProfile(user)` | Promise | Upsert `public.profiles` row |
| `createOrLoadPersonalWorkspace(id)` | Promise | Upsert personal workspace + owner membership |

**Local mode safety:** Every method returns a safe default (null, empty object, or `{ error: null }`) when Supabase is not configured. No exceptions are thrown.

**localStorage cache: `px_auth_identity_v1`**

```json
{
  "userId": "uuid-from-supabase",
  "email": "user@example.com",
  "displayName": "Amara",
  "supabaseWorkspaceId": "uuid-of-cloud-workspace",
  "signedInAt": "2026-05-21T18:00:00.000Z"
}
```

Cached on sign-in; cleared on sign-out. Survives page reload. Used for UI display without requiring a Supabase round-trip.

---

## Part 2 — Auth UI

### Auth sheet (dynamically injected)

The auth sheet is a cinematic bottom sheet following the same visual language as the Ask Parallel AI sheet:

- Glass background: `linear-gradient(175deg, rgba(248,244,240,.99), ...)`
- Border radius: `28px 28px 0 0`
- Transition: `var(--cinematic)` easing
- `position: fixed` — covers the whole screen regardless of scroll
- z-index: `3800` (above AI sheet at `3700`)
- Backdrop tap closes the sheet

**Three views rendered inside the sheet:**

| View | When shown |
|---|---|
| **Local mode** | Supabase not configured (no real credentials) |
| **Sign in / Sign up form** | Supabase configured; user not signed in |
| **Signed in state** | Active session detected |

**Sign in / Sign up form fields:**
- Display name (sign up only)
- Email
- Password
- Error / success message area
- Inline error rendering (no page navigation)
- "Stay local for now" cancel link
- Local workspace reassurance note

**Signed in view shows:**
- Collaborator initials avatar (from existing `ParallelCollaborators.avatarColor`)
- Display name and email
- "Cloud identity connected" lilac badge
- Honest message: "Your workspace is still local. Cloud save coming next."
- "Signed in · Cloud save coming next. No data has been uploaded yet."
- Sign out button

**Entry point:** Tapping the `backend-status-chip` in the Studio Pulse ribbon opens the auth sheet. The chip is clickable at all times. Event delegation handles all chips anywhere on the page.

**No auth wall:** The app never opens the auth sheet automatically. It never blocks navigation. Users can dismiss it and continue in local mode indefinitely.

---

## Part 3 — Profile + Workspace Identity

### Profile (`public.profiles`)

On sign-in (via `handleAuthChange`), `createOrLoadProfile(user)` runs:

1. `SELECT * FROM profiles WHERE id = auth.uid()`
2. If found: loads the row into `_profile`
3. If not found: inserts a new row with:
   - `id`: Supabase auth UID
   - `display_name`: resolved from `user.user_metadata.display_name` → `px_v19_name` → email prefix
   - `email`: from Supabase user
   - `role_default`: `'owner'`
   - `is_local`: `false`

### Personal workspace (`public.workspaces`)

On sign-in, `createOrLoadPersonalWorkspace(userId)` runs:

1. `SELECT * FROM workspaces WHERE owner_id = auth.uid()` (oldest first)
2. If found: loads the workspace ID into `_wsId`
3. If not found: inserts a new workspace with:
   - `name`: from `px_workspace_name` or `px_v19_name + "'s Workspace"`
   - `mode`: from `px_v19_mode`
   - `owner_id`: auth UID
   - `settings.syncEnabled`: `false` (Phase 24C enables this)
   - Also inserts an `owner` row in `workspace_members`

The cloud workspace ID is stored in `px_auth_identity_v1.supabaseWorkspaceId` for use in Phase 24C data migration.

---

## Part 4 — Local User → Auth User Mapping

### Collaborator ID map: `px_collab_id_map_v1`

On sign-in, the local owner's collaborator ID (e.g. `collab-amara`) is mapped to the Supabase auth UUID:

```json
{ "collab-amara": "real-supabase-uuid-here" }
```

This mapping persists across sign-out. Future phases use it to:
- Resolve attribution (`createdBy`, `updatedBy`) from local IDs to cloud UUIDs
- Hydrate record/page history with real user identity
- Support multi-device attribution

### ParallelCollaborators integration

After sign-in, `ParallelCollaborators.register()` is called with the authenticated user's real data:

```js
ParallelCollaborators.register({
  id:          'collab-amara',       // keeps local ID for backward compat
  displayName: 'Amara',              // from Supabase profile
  email:       'amara@example.com',  // from Supabase user
  role:        'owner',
  isLocal:     false,
  authUserId:  'uuid-from-supabase', // new: Supabase auth UUID
});
```

Existing mock collaborators (Kaia, Jad, Rami, Maya) are **not removed** — they continue as workspace team members. Only the owner's identity is upgraded to real auth.

---

## Part 5 — Session State UX

### Backend status chip (Studio Pulse ribbon)

The existing chip from Phase 24A now reflects auth state and is always tappable:

| State | Chip appearance |
|---|---|
| Local workspace | `[⊙] Local workspace` (sage) |
| Cloud ready (signed out) | `[↑] Cloud ready` (lilac) |
| Signed in | `[☁] Signed in` (lilac) |

Tapping any chip opens the auth sheet. The `updateAuthChip()` function is called:
- After every `onAuthStateChange` event
- After sign-in / sign-out
- On `initAuthSystem()`

### Intentionally honest copy

The signed-in state never claims sync is active. All copy is future-honest:
- "Cloud identity connected"
- "Cloud save coming next"
- "No data has been uploaded yet"
- "Your local workspace is unchanged"

---

## Part 6 — Auth System Initialization

`initAuthSystem()` is called during app boot (after `initBackendStatus()`):

1. Calls `ParallelAuth.initialize()` — subscribes to Supabase auth state changes, restores existing session
2. Registers an `onAuthStateChange` listener that updates the chip and re-renders the auth sheet if open
3. Attaches a document-level click listener for `.backend-status-chip` clicks
4. Calls `updateAuthChip()` to reflect current state (including cached identity from prior session)
5. Logs auth mode to console

In `apps/studio/index.html`, calls use the defensive `if(window.initAuthSystem)` guard pattern.

---

## Part 7 — Preservation + Regression Audit

### All Phase 1–23 features confirmed intact

| System | Status |
|---|---|
| Global shell — one footer, one plus button, dock order | ✅ |
| Studio Command Center (all sections) | ✅ |
| Onboarding Phase 19 | ✅ |
| Ask Parallel AI sheet Phase 20 | ✅ |
| AI Actions on records | ✅ |
| All 6 database views + Grouped List | ✅ |
| Record editor: properties, relations, rollups, formulas, block body | ✅ |
| Phase 23 collaboration: comments, activity, avatars, attributions | ✅ |
| Phase 24A backend config + status chip | ✅ |
| App opens with no Supabase credentials — full local mode | ✅ |
| Auth sheet does not open automatically | ✅ |
| Auth sheet dismissible — local mode continues | ✅ |
| No data migrated or wiped | ✅ |
| All existing localStorage keys unchanged | ✅ |
| Legacy files byte-for-byte identical | ✅ |

### localStorage safety audit

| Key | Phase | Phase 24B change |
|---|---|---|
| `parallel.studio.phase4.v2` | Phase 4 | Unchanged |
| `px_schema_version` | Phase 22 | Unchanged |
| `px_workspace_id` | Phase 22 | Unchanged |
| `px_workspace_name` | Phase 22 | Unchanged |
| `px_v19_*` | Phase 19 | Unchanged — only read, never written |
| `px_activity_v1` | Phase 23 | Unchanged |
| `px_comments_v1` | Phase 23 | Unchanged |
| `px_auth_identity_v1` | **Phase 24B** | New — cached auth state (set on sign-in, cleared on sign-out) |
| `px_collab_id_map_v1` | **Phase 24B** | New — local collab ID → Supabase UUID mapping |

---

## Files Added / Changed

| File | Type | Description |
|---|---|---|
| `systems/backend/auth.js` | New | Supabase Auth wrapper + profile/workspace bootstrap |
| `apps/app/index.html` | Modified | Auth.js script tag, Phase 24B CSS, auth sheet JS, initAuthSystem call |
| `apps/studio/index.html` | Modified | Same changes mirrored (defensive guards) |
| `docs/PHASE24B_SUPABASE_AUTH_WORKSPACE_IDENTITY.md` | New | This file |
| `README.md` | Modified | Phase 24B entry added |

---

## Remaining Deferred Work

1. **No data uploaded yet** — `signIn()` + profile/workspace creation happen in Supabase, but existing localStorage workspace data (pages, databases, records) is not synced. Phase 24C adds the first real cloud save/load.

2. **ID mapping not resolved yet for attribution** — `px_collab_id_map_v1` stores the mapping but `createdBy`/`updatedBy` on entities still hold `collab-*` strings. Phase 24C resolves these when uploading data.

3. **OAuth / magic link not implemented** — Only email + password auth is wired. Phase 24B+ can add `signInWithOAuth()` for Google, GitHub, etc.

4. **Session stored by Supabase SDK only** — Supabase handles its own session persistence (`localStorage` under Supabase's own keys). Phase 24B does not interfere with this.

5. **No session expiry handling** — Supabase auto-refreshes tokens when the SDK is loaded. No explicit handling needed until Phase 24C.

6. **Workspace members not wired** — When a Supabase workspace is created, only the owner membership row is inserted. Inviting team members to the real cloud workspace requires a future invite flow.

7. **Profile avatar not uploaded** — `avatar_url` in `public.profiles` is null. Phase 24C+ can add avatar upload to Supabase Storage.
