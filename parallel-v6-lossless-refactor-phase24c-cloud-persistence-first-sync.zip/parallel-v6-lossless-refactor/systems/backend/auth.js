/* ─────────────────────────────────────────────────────────────────────────
   Parallel Auth — Phase 24B: Supabase Auth + Workspace Identity

   Thin, safe wrapper around Supabase Auth.

   Design principles:
     - NEVER crash or block if Supabase is not configured
     - NEVER force login or redirect to a login screen
     - NEVER clear or migrate localStorage workspace data
     - Always return graceful local-mode results
     - All methods are safe to call regardless of configuration

   Dependencies (must load before this file):
     - backend-config.js
     - supabase-client.js

   Local state cache: px_auth_identity_v1
     { userId, email, displayName, supabaseWorkspaceId, signedInAt }

   Collaborator ID map: px_collab_id_map_v1
     { 'collab-amara': 'uuid-from-supabase', ... }
     Persists across sign-out so past attributions can be resolved.

   Auth modes:
     'local'      — Supabase not configured; app runs fully offline
     'signed-out' — Supabase configured; user not signed in
     'signed-in'  — User has an active Supabase session

   Intentionally deferred:
     - Cloud data save/load (Phase 24C)
     - Sync queue (Phase 24D)
     - Realtime subscriptions (Phase 24E)
     - OAuth / magic link sign-in (future)
────────────────────────────────────────────────────────────────────────── */

(function (global) {
  'use strict';

  var IDENTITY_KEY    = 'px_auth_identity_v1';
  var COLLAB_MAP_KEY  = 'px_collab_id_map_v1';

  /* ── In-memory state ─────────────────────────────────────────────── */
  var _session        = null;   // Supabase Session object
  var _user           = null;   // Supabase User object
  var _profile        = null;   // public.profiles row
  var _wsId           = null;   // Supabase workspace UUID
  var _initialized    = false;
  var _listeners      = [];

  /* ── Safe Supabase client accessor ──────────────────────────────── */
  function client() {
    return (global.ParallelSupabaseClient && global.ParallelSupabaseClient.getClient()) || null;
  }

  function tables() {
    return (global.ParallelBackendConfig && global.ParallelBackendConfig.TABLES) || {};
  }

  /* ── Notify listeners + dispatch browser event ──────────────────── */
  function notifyListeners(event, session) {
    _listeners.forEach(function (fn) {
      try { fn(event, session); } catch (e) {}
    });
    try {
      window.dispatchEvent(new CustomEvent('parallelAuthChange', {
        detail: { event: event, session: session },
      }));
    } catch (e) {}
  }

  /* ── localStorage helpers ────────────────────────────────────────── */
  function lsGet(key) {
    try { var r = localStorage.getItem(key); return r ? JSON.parse(r) : null; } catch (e) { return null; }
  }
  function lsSet(key, val) {
    try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) {}
  }
  function lsRemove(key) {
    try { localStorage.removeItem(key); } catch (e) {}
  }

  /* ── Cached identity helpers ─────────────────────────────────────── */
  function getCachedIdentity() { return lsGet(IDENTITY_KEY); }

  function saveCachedIdentity(opts) {
    lsSet(IDENTITY_KEY, {
      userId:              opts.userId              || null,
      email:               opts.email               || null,
      displayName:         opts.displayName          || 'User',
      supabaseWorkspaceId: opts.supabaseWorkspaceId || null,
      signedInAt:          new Date().toISOString(),
    });
  }

  function clearCachedIdentity() { lsRemove(IDENTITY_KEY); }

  /* ── Collaborator ID mapping ─────────────────────────────────────── */
  function saveCollabMapping(localCollabId, authUserId) {
    var map = lsGet(COLLAB_MAP_KEY) || {};
    map[localCollabId] = authUserId;
    lsSet(COLLAB_MAP_KEY, map);
  }

  function getCollabMapping() { return lsGet(COLLAB_MAP_KEY) || {}; }

  /* ── Find the current device-owner's local collaborator ID ────────
     Resolves to 'collab-amara' (or whatever the onboarding produced).
  ────────────────────────────────────────────────────────────────── */
  function resolveLocalOwnerCollabId() {
    if (global.ParallelCollaborators) {
      var me = global.ParallelCollaborators.me;
      return me ? me.id : null;
    }
    return null;
  }

  /* ── Resolve display name for a new user ─────────────────────────── */
  function resolveDisplayName(user) {
    return (
      (user.user_metadata && user.user_metadata.display_name) ||
      (user.user_metadata && user.user_metadata.full_name)    ||
      (function () { try { return localStorage.getItem('px_v19_name'); } catch (e) { return null; } })() ||
      (user.email ? user.email.split('@')[0] : 'User')
    );
  }

  /* ── Create or load a profile row ──────────────────────────────── */
  function createOrLoadProfile(user) {
    var c = client();
    if (!c || !user) return Promise.resolve(null);

    var displayName = resolveDisplayName(user);
    var T = tables();

    return c
      .from(T.profiles)
      .select('*')
      .eq('id', user.id)
      .maybeSingle()
      .then(function (res) {
        if (res.data) { _profile = res.data; return _profile; }

        // Profile doesn't exist — create it
        return c
          .from(T.profiles)
          .insert({
            id:           user.id,
            display_name: displayName,
            email:        user.email || null,
            role_default: 'owner',
            is_local:     false,
          })
          .select()
          .maybeSingle()
          .then(function (ins) {
            _profile = ins.data;
            return _profile;
          });
      })
      .catch(function (e) {
        console.warn('[Parallel Auth] Profile load/create failed:', e.message || e);
        return null;
      });
  }

  /* ── Create or load personal workspace ─────────────────────────── */
  function createOrLoadPersonalWorkspace(userId) {
    var c = client();
    if (!c || !userId) return Promise.resolve(null);

    var T = tables();
    var wsName = (function () {
      try {
        return localStorage.getItem('px_workspace_name') ||
               (localStorage.getItem('px_v19_name') || '') + "'s Workspace" ||
               'My Workspace';
      } catch (e) { return 'My Workspace'; }
    })();
    var wsMode = (function () {
      try { return localStorage.getItem('px_v19_mode') || 'personal'; } catch (e) { return 'personal'; }
    })();

    return c
      .from(T.workspaces)
      .select('*')
      .eq('owner_id', userId)
      .is('deleted_at', null)
      .order('created_at', { ascending: true })
      .limit(1)
      .then(function (res) {
        if (res.data && res.data.length > 0) {
          _wsId = res.data[0].id;
          return res.data[0];
        }

        // No workspace — create one
        return c
          .from(T.workspaces)
          .insert({
            name:           wsName,
            mode:           wsMode,
            owner_id:       userId,
            schema_version: 2,
            settings: {
              onboardingDone:          true,
              gettingStartedDismissed: false,
              workspaceMode:           wsMode,
              userName:                _profile ? _profile.display_name : 'User',
              syncEnabled:             false,
            },
          })
          .select()
          .maybeSingle()
          .then(function (ins) {
            if (!ins.data) return null;
            _wsId = ins.data.id;
            // Insert owner membership row
            return c
              .from(T.workspaceMembers)
              .insert({ workspace_id: _wsId, user_id: userId, role: 'owner' })
              .then(function () { return ins.data; })
              .catch(function () { return ins.data; });  // membership failure is non-fatal
          });
      })
      .catch(function (e) {
        console.warn('[Parallel Auth] Workspace load/create failed:', e.message || e);
        return null;
      });
  }

  /* ── Auth state change handler ──────────────────────────────────── */
  function handleAuthChange(event, session) {
    _session = session;
    _user    = session ? session.user : null;

    if (_user) {
      var localCollabId = resolveLocalOwnerCollabId();

      createOrLoadProfile(_user)
        .then(function (profile) {
          return createOrLoadPersonalWorkspace(_user.id)
            .then(function (ws) {
              var displayName = (profile && profile.display_name) ||
                                resolveDisplayName(_user);

              saveCachedIdentity({
                userId:              _user.id,
                email:               _user.email,
                displayName:         displayName,
                supabaseWorkspaceId: ws ? ws.id : null,
              });

              // Map local collab ID → Supabase auth UUID
              if (localCollabId) {
                saveCollabMapping(localCollabId, _user.id);
              }

              // Update the collaborators module with real identity
              if (global.ParallelCollaborators && typeof global.ParallelCollaborators.register === 'function') {
                global.ParallelCollaborators.register({
                  id:          localCollabId || ('auth_' + _user.id),
                  displayName: displayName,
                  email:       _user.email,
                  role:        'owner',
                  isLocal:     false,
                  authUserId:  _user.id,
                });
              }

              notifyListeners(event, session);
            });
        })
        .catch(function (e) {
          console.warn('[Parallel Auth] Post-sign-in setup failed:', e.message || e);
          notifyListeners(event, session);
        });
    } else {
      // Signed out — clear in-memory state; cached identity cleared separately
      _profile = null;
      _wsId    = null;
      clearCachedIdentity();
      notifyListeners(event, session);
    }
  }

  /* ── Public API ─────────────────────────────────────────────────── */
  var ParallelAuth = {

    /* ─ State ───────────────────────────────────────────────────────── */

    /** Whether the Supabase client is ready (configured + SDK loaded) */
    get isReady() {
      return !!(global.ParallelSupabaseClient && global.ParallelSupabaseClient.isActive);
    },

    /** Whether a user is currently signed in (in-memory or cached) */
    get isSignedIn() {
      if (_user) return true;
      var cached = getCachedIdentity();
      return !!(cached && cached.userId);
    },

    /** 'local' | 'signed-out' | 'signed-in' */
    get authMode() {
      if (!global.ParallelBackendConfig || !global.ParallelBackendConfig.isConfigured()) {
        return 'local';
      }
      return _user ? 'signed-in' : 'signed-out';
    },

    /** Display name for the current user */
    get displayName() {
      if (_profile)  return _profile.display_name;
      if (_user)     return resolveDisplayName(_user);
      var cached = getCachedIdentity();
      if (cached && cached.displayName) return cached.displayName;
      try { return localStorage.getItem('px_v19_name') || 'User'; } catch (e) { return 'User'; }
    },

    /** Status label for the backend chip UI */
    get statusLabel() {
      var mode = this.authMode;
      if (mode === 'local')      return 'Local workspace';
      if (mode === 'signed-out') return 'Cloud ready';
      return 'Signed in';
    },

    /** Raw Supabase User object (null in local/signed-out mode) */
    get user() { return _user; },

    /** Raw Supabase Session object (null in local/signed-out mode) */
    get session() { return _session; },

    /** The loaded public.profiles row (null until sign-in) */
    get profile() { return _profile; },

    /** Supabase workspace UUID (null until workspace is created) */
    get supabaseWorkspaceId() {
      if (_wsId) return _wsId;
      var cached = getCachedIdentity();
      return cached ? cached.supabaseWorkspaceId : null;
    },

    /** Map of local collab IDs to Supabase auth UUIDs */
    get collabIdMap() { return getCollabMapping(); },

    /** Cached identity from localStorage */
    getCachedIdentity: getCachedIdentity,

    /* ─ Lifecycle ───────────────────────────────────────────────────── */

    /**
     * Initialize the auth system. Subscribes to Supabase auth state changes
     * and loads the current session. Safe to call in local mode.
     */
    initialize: function () {
      if (_initialized) return;
      _initialized = true;

      var c = client();
      if (!c) {
        console.info('[Parallel Auth] Local mode — auth system inactive.');
        return;
      }

      try {
        // Subscribe to future auth state changes
        c.auth.onAuthStateChange(function (event, session) {
          handleAuthChange(event, session);
        });

        // Restore existing session (e.g. after page reload)
        c.auth.getSession()
          .then(function (res) {
            if (res.data && res.data.session) {
              handleAuthChange('INITIAL_SESSION', res.data.session);
            }
          })
          .catch(function (e) {
            console.warn('[Parallel Auth] Session restore failed:', e.message || e);
          });
      } catch (e) {
        console.warn('[Parallel Auth] Auth init failed:', e.message || e);
      }
    },

    /* ─ Auth operations ─────────────────────────────────────────────── */

    /** Sign in with email and password. Returns Promise<{user, session, error}>. */
    signIn: function (email, password) {
      var c = client();
      if (!c) return Promise.resolve({ user: null, session: null, error: { message: 'Supabase not configured' } });
      return c.auth.signInWithPassword({ email: email, password: password })
        .then(function (res) {
          return {
            user:    res.data && res.data.user    || null,
            session: res.data && res.data.session || null,
            error:   res.error || null,
          };
        })
        .catch(function (e) {
          return { user: null, session: null, error: { message: e.message || String(e) } };
        });
    },

    /**
     * Sign up with email, password, and optional display name.
     * Returns Promise<{user, session, error}>.
     * Note: Supabase may require email confirmation before a session is issued.
     */
    signUp: function (email, password, displayName) {
      var c = client();
      if (!c) return Promise.resolve({ user: null, session: null, error: { message: 'Supabase not configured' } });
      return c.auth.signUp({
        email:    email,
        password: password,
        options: {
          data: { display_name: displayName || (email.split('@')[0]) },
        },
      })
        .then(function (res) {
          return {
            user:    res.data && res.data.user    || null,
            session: res.data && res.data.session || null,
            error:   res.error || null,
          };
        })
        .catch(function (e) {
          return { user: null, session: null, error: { message: e.message || String(e) } };
        });
    },

    /**
     * Sign out. Clears cached identity.
     * Local workspace data is NEVER touched.
     * Returns Promise<{error}>.
     */
    signOut: function () {
      clearCachedIdentity();
      var c = client();
      if (!c) return Promise.resolve({ error: null });
      return c.auth.signOut()
        .then(function (res) { return { error: res.error || null }; })
        .catch(function (e) { return { error: { message: e.message || String(e) } }; });
    },

    /** Get the current session. Returns Promise<{session, error}>. */
    getSession: function () {
      var c = client();
      if (!c) return Promise.resolve({ session: null, error: null });
      return c.auth.getSession()
        .then(function (res) { return { session: res.data && res.data.session || null, error: res.error || null }; })
        .catch(function (e) { return { session: null, error: { message: e.message || String(e) } }; });
    },

    /** Get the current user. Returns Promise<{user, error}>. */
    getUser: function () {
      var c = client();
      if (!c) return Promise.resolve({ user: null, error: null });
      return c.auth.getUser()
        .then(function (res) { return { user: res.data && res.data.user || null, error: res.error || null }; })
        .catch(function (e) { return { user: null, error: { message: e.message || String(e) } }; });
    },

    /**
     * Subscribe to auth state changes.
     * Callback receives (event: string, session: Session|null).
     * Safe in local mode — callback is stored and called if Supabase activates later.
     */
    onAuthStateChange: function (callback) {
      if (typeof callback === 'function') {
        _listeners.push(callback);
      }
    },

    /** Profile and workspace bootstrap — called automatically after sign-in */
    createOrLoadProfile:          createOrLoadProfile,
    createOrLoadPersonalWorkspace: createOrLoadPersonalWorkspace,
  };

  global.ParallelAuth = ParallelAuth;

})(window);
