/* ─────────────────────────────────────────────────────────────────────────
   Parallel Cloud — Phase 24C: Cloud Persistence + First Sync

   Handles the first real cloud save and cloud load for a signed-in user.

   Design principles:
     - NEVER overwrite local workspace without explicit user confirmation
     - NEVER wipe localStorage — local data is always the source of truth
     - NEVER claim realtime sync exists — this is one-shot upload / download
     - NEVER run in local mode — all methods are no-ops without a live session
     - Always create a local backup before hydrating from cloud
     - Always be idempotent — re-uploading is safe; re-downloading is safe
     - All progress events are cancelable; failures leave local data intact

   Dependencies (must load before this file):
     - backend-config.js (ParallelBackendConfig)
     - supabase-client.js (ParallelSupabaseClient)
     - auth.js (ParallelAuth)

   localStorage keys added by this module:
     px_cloud_id_map_v1   — { pages:{}, databases:{}, records:{},
                               comments:{}, activity:{} }
                             Maps local string IDs → Supabase UUIDs.
                             Written on first upload; read on every subsequent
                             upload to perform UPDATEs instead of INSERTs.

     px_cloud_sync_v1     — { lastUploadAt, lastDownloadAt, uploadCount,
                               downloadCount, lastError }
                             Persists across sessions for status display.

     px_local_backup_v1   — { workspace, comments, activity, backedUpAt }
                             Written immediately before any cloudLoad() call.
                             Never written by cloudSave(). Never auto-deleted.

   Entity upload order (satisfies FK constraints):
     1. workspace row  (workspaces)
     2. databases       (databases)
     3. records         (database_records)
     4. pages           (pages — metadata.blocks JSONB strategy)
     5. comments        (comments)
     6. activity events (activity_events)

   Intentionally deferred:
     - Realtime subscriptions (Phase 24E)
     - Conflict resolution / merging (Phase 24F)
     - Asset / file upload (Phase 24G)
     - Incremental sync / dirty-flag queue (Phase 24D)
────────────────────────────────────────────────────────────────────────── */

(function (global) {
  'use strict';

  var ID_MAP_KEY    = 'px_cloud_id_map_v1';
  var SYNC_KEY      = 'px_cloud_sync_v1';
  var BACKUP_KEY    = 'px_local_backup_v1';
  var WS_KEY        = 'parallel.studio.phase4.v2';
  var COMMENTS_KEY  = 'px_comments_v1';
  var ACTIVITY_KEY  = 'px_activity_v1';
  var COLLAB_MAP_KEY = 'px_collab_id_map_v1';

  /* ── localStorage helpers ────────────────────────────────────────── */
  function lsGet(key) {
    try { var r = localStorage.getItem(key); return r ? JSON.parse(r) : null; } catch (e) { return null; }
  }
  function lsSet(key, val) {
    try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) {}
  }
  function lsRaw(key) {
    try { return localStorage.getItem(key); } catch (e) { return null; }
  }

  /* ── ID map helpers ──────────────────────────────────────────────── */
  function getIdMap() {
    return lsGet(ID_MAP_KEY) || { pages: {}, databases: {}, records: {}, comments: {}, activity: {} };
  }
  function saveIdMap(map) { lsSet(ID_MAP_KEY, map); }

  /* ── Sync status helpers ─────────────────────────────────────────── */
  function getSyncStatus() {
    return lsGet(SYNC_KEY) || {
      lastUploadAt:   null,
      lastDownloadAt: null,
      uploadCount:    0,
      downloadCount:  0,
      lastError:      null,
    };
  }
  function updateSyncStatus(patch) {
    var s = getSyncStatus();
    Object.assign(s, patch);
    lsSet(SYNC_KEY, s);
  }

  /* ── Local backup ────────────────────────────────────────────────── */
  function createLocalBackup() {
    try {
      lsSet(BACKUP_KEY, {
        workspace:  lsGet(WS_KEY),
        comments:   lsGet(COMMENTS_KEY),
        activity:   lsGet(ACTIVITY_KEY),
        backedUpAt: new Date().toISOString(),
      });
      console.info('[Parallel Cloud] Local backup created → px_local_backup_v1');
      return true;
    } catch (e) {
      console.warn('[Parallel Cloud] Backup failed:', e.message || e);
      return false;
    }
  }

  /* ── User ID resolver ────────────────────────────────────────────── */
  function resolveUserId(localCollabId) {
    if (!localCollabId) {
      return (global.ParallelAuth && global.ParallelAuth.user) ? global.ParallelAuth.user.id : null;
    }
    var map = lsGet(COLLAB_MAP_KEY) || {};
    if (map[localCollabId]) return map[localCollabId];
    return (global.ParallelAuth && global.ParallelAuth.user) ? global.ParallelAuth.user.id : null;
  }

  /* ── Progress emitter ────────────────────────────────────────────── */
  function emitProgress(step, total, label, status) {
    try {
      global.dispatchEvent(new CustomEvent('parallelCloudProgress', {
        detail: { step: step, total: total, label: label, status: status || 'running' },
      }));
    } catch (e) {}
  }

  /* ── Safe client + tables ────────────────────────────────────────── */
  function client() {
    return (global.ParallelSupabaseClient && global.ParallelSupabaseClient.getClient()) || null;
  }
  function T() {
    return (global.ParallelBackendConfig && global.ParallelBackendConfig.TABLES) || {};
  }
  function currentUserId() {
    return global.ParallelAuth ? global.ParallelAuth.user && global.ParallelAuth.user.id : null;
  }
  function cloudWsId() {
    return global.ParallelAuth ? global.ParallelAuth.supabaseWorkspaceId : null;
  }

  /* ─────────────────────────────────────────────────────────────────
     UPLOAD HELPERS
     Each helper: upserts one entity; returns the cloud UUID.
  ─────────────────────────────────────────────────────────────────── */

  function uploadDatabase(db, wsUuid, idMap, userId) {
    var c = client(); var tbl = T();
    var existingId = idMap.databases[db.id];
    var row = {
      workspace_id: wsUuid,
      name:         db.name        || 'Untitled',
      icon:         db.icon        || null,
      color:        db.color       || null,
      fields:       db.fields      || [],
      views:        db.views       || [],
      settings:     db.settings    || {},
      created_by:   resolveUserId(db.createdBy) || userId,
      updated_by:   userId,
    };
    if (existingId) {
      return c.from(tbl.databases).update(row).eq('id', existingId).select('id').maybeSingle()
        .then(function (r) { return existingId; })
        .catch(function () { return existingId; });
    }
    return c.from(tbl.databases).insert(Object.assign({ id: undefined }, row)).select('id').maybeSingle()
      .then(function (r) { return r.data ? r.data.id : null; })
      .catch(function () { return null; });
  }

  function uploadRecord(rec, dbUuid, wsUuid, idMap, userId) {
    var c = client(); var tbl = T();
    var existingId = idMap.records[rec.id];
    var row = {
      workspace_id: wsUuid,
      database_id:  dbUuid,
      fields:       rec.fields      || {},
      blocks:       rec.blocks       || [],
      status:       rec.status       || null,
      tags:         rec.tags         || [],
      relations:    [],
      created_by:   resolveUserId(rec.createdBy) || userId,
      updated_by:   resolveUserId(rec.updatedBy) || userId,
    };
    if (existingId) {
      return c.from(tbl.records).update(row).eq('id', existingId).select('id').maybeSingle()
        .then(function () { return existingId; })
        .catch(function () { return existingId; });
    }
    return c.from(tbl.records).insert(row).select('id').maybeSingle()
      .then(function (r) { return r.data ? r.data.id : null; })
      .catch(function () { return null; });
  }

  function uploadPage(page, wsUuid, idMap, userId) {
    var c = client(); var tbl = T();
    var existingId = idMap.pages[page.id];
    var row = {
      workspace_id: wsUuid,
      title:        page.title       || 'Untitled',
      icon:         page.icon        || null,
      cover:        page.cover       || null,
      parent_id:    page.parentId    ? (idMap.pages[page.parentId] || null) : null,
      metadata:     Object.assign({}, page.metadata || {}, {
                      blocks: page.blocks || page.body || [],
                    }),
      created_by:   resolveUserId(page.createdBy) || userId,
      updated_by:   resolveUserId(page.updatedBy) || userId,
    };
    if (existingId) {
      return c.from(tbl.pages).update(row).eq('id', existingId).select('id').maybeSingle()
        .then(function () { return existingId; })
        .catch(function () { return existingId; });
    }
    return c.from(tbl.pages).insert(row).select('id').maybeSingle()
      .then(function (r) { return r.data ? r.data.id : null; })
      .catch(function () { return null; });
  }

  function uploadComment(comment, wsUuid, idMap, userId) {
    var c = client(); var tbl = T();
    var existingId = idMap.comments[comment.id];
    var row = {
      workspace_id:  wsUuid,
      entity_type:   comment.entityType  || 'record',
      entity_id:     idMap.records[comment.entityId] || idMap.pages[comment.entityId] || null,
      body:          comment.body        || '',
      author_id:     resolveUserId(comment.authorId || comment.createdBy) || userId,
      is_resolved:   !!(comment.isResolved || comment.resolved),
      resolved_by:   comment.resolvedBy ? (resolveUserId(comment.resolvedBy) || userId) : null,
    };
    if (existingId) {
      return c.from(tbl.comments).update(row).eq('id', existingId).select('id').maybeSingle()
        .then(function () { return existingId; })
        .catch(function () { return existingId; });
    }
    return c.from(tbl.comments).insert(row).select('id').maybeSingle()
      .then(function (r) { return r.data ? r.data.id : null; })
      .catch(function () { return null; });
  }

  function uploadActivityEvent(ev, wsUuid, idMap, userId) {
    var c = client(); var tbl = T();
    var existingId = idMap.activity[ev.id];
    if (existingId) return Promise.resolve(existingId); // activity is append-only; skip if already uploaded
    var row = {
      workspace_id: wsUuid,
      actor_id:     resolveUserId(ev.actorId || ev.userId || ev.createdBy) || userId,
      event_type:   ev.type || ev.eventType || 'unknown',
      entity_type:  ev.entityType || null,
      entity_id:    idMap.records[ev.entityId] || idMap.pages[ev.entityId] || null,
      payload:      ev.payload || ev.data || {},
    };
    return c.from(tbl.activity).insert(row).select('id').maybeSingle()
      .then(function (r) { return r.data ? r.data.id : null; })
      .catch(function () { return null; });
  }

  /* ─────────────────────────────────────────────────────────────────
     CLOUD SAVE — sequential upload of all local workspace data
  ─────────────────────────────────────────────────────────────────── */

  function cloudSave() {
    var c = client();
    if (!c) return Promise.reject(new Error('Supabase not configured'));

    var auth = global.ParallelAuth;
    if (!auth || !auth.isSignedIn) return Promise.reject(new Error('Not signed in'));

    var wsUuid  = cloudWsId();
    var userId  = currentUserId();
    if (!wsUuid || !userId) return Promise.reject(new Error('Workspace or user ID missing'));

    var workspace = lsGet(WS_KEY);
    if (!workspace) return Promise.reject(new Error('No local workspace found'));

    var idMap    = getIdMap();
    var tbl      = T();
    var TOTAL    = 6;
    var step     = 0;

    emitProgress(step, TOTAL, 'Starting upload…', 'running');

    /* ── Step 1 — Workspace metadata ──────────────────────────── */
    return (function uploadWorkspaceMeta() {
      step = 1;
      emitProgress(step, TOTAL, 'Saving workspace…', 'running');
      var wsRow = {
        name:           workspace.name || lsRaw('px_workspace_name') || 'My Workspace',
        mode:           workspace.mode || lsRaw('px_v19_mode') || 'personal',
        settings: Object.assign(
          { syncEnabled: false },
          workspace.settings || {}
        ),
        schema_version: 2,
        updated_at:     new Date().toISOString(),
      };
      return c.from(tbl.workspaces).update(wsRow).eq('id', wsUuid)
        .then(function () { return null; })
        .catch(function () { return null; }); // non-fatal
    })()

    /* ── Step 2 — Databases ───────────────────────────────────── */
    .then(function () {
      step = 2;
      emitProgress(step, TOTAL, 'Saving databases…', 'running');
      var databases = workspace.databases || [];
      if (!databases.length) return Promise.resolve();
      return databases.reduce(function (chain, db) {
        return chain.then(function () {
          return uploadDatabase(db, wsUuid, idMap, userId)
            .then(function (cloudId) {
              if (cloudId) { idMap.databases[db.id] = cloudId; saveIdMap(idMap); }
            });
        });
      }, Promise.resolve());
    })

    /* ── Step 3 — Records ─────────────────────────────────────── */
    .then(function () {
      step = 3;
      emitProgress(step, TOTAL, 'Saving records…', 'running');
      var databases = workspace.databases || [];
      return databases.reduce(function (chain, db) {
        var dbUuid = idMap.databases[db.id];
        if (!dbUuid) return chain;
        var records = db.records || [];
        return records.reduce(function (rc, rec) {
          return rc.then(function () {
            return uploadRecord(rec, dbUuid, wsUuid, idMap, userId)
              .then(function (cloudId) {
                if (cloudId) { idMap.records[rec.id] = cloudId; saveIdMap(idMap); }
              });
          });
        }, chain);
      }, Promise.resolve());
    })

    /* ── Step 4 — Pages ───────────────────────────────────────── */
    .then(function () {
      step = 4;
      emitProgress(step, TOTAL, 'Saving pages…', 'running');
      var pages = workspace.pages || [];
      // Upload root pages first (no parentId), then children
      var roots = pages.filter(function (p) { return !p.parentId; });
      var children = pages.filter(function (p) { return !!p.parentId; });
      var ordered = roots.concat(children);
      return ordered.reduce(function (chain, page) {
        return chain.then(function () {
          return uploadPage(page, wsUuid, idMap, userId)
            .then(function (cloudId) {
              if (cloudId) { idMap.pages[page.id] = cloudId; saveIdMap(idMap); }
            });
        });
      }, Promise.resolve());
    })

    /* ── Step 5 — Comments ────────────────────────────────────── */
    .then(function () {
      step = 5;
      emitProgress(step, TOTAL, 'Saving comments…', 'running');
      var comments = lsGet(COMMENTS_KEY) || [];
      return comments.reduce(function (chain, comment) {
        return chain.then(function () {
          return uploadComment(comment, wsUuid, idMap, userId)
            .then(function (cloudId) {
              if (cloudId) { idMap.comments[comment.id] = cloudId; saveIdMap(idMap); }
            });
        });
      }, Promise.resolve());
    })

    /* ── Step 6 — Activity events ─────────────────────────────── */
    .then(function () {
      step = 6;
      emitProgress(step, TOTAL, 'Saving activity…', 'running');
      var events = lsGet(ACTIVITY_KEY) || [];
      return events.reduce(function (chain, ev) {
        return chain.then(function () {
          return uploadActivityEvent(ev, wsUuid, idMap, userId)
            .then(function (cloudId) {
              if (cloudId) { idMap.activity[ev.id] = cloudId; saveIdMap(idMap); }
            });
        });
      }, Promise.resolve());
    })

    /* ── Done ─────────────────────────────────────────────────── */
    .then(function () {
      emitProgress(TOTAL, TOTAL, 'Upload complete', 'done');
      updateSyncStatus({
        lastUploadAt: new Date().toISOString(),
        uploadCount:  (getSyncStatus().uploadCount || 0) + 1,
        lastError:    null,
      });
      console.info('[Parallel Cloud] cloudSave() complete.');
    })
    .catch(function (e) {
      var msg = e && e.message ? e.message : String(e);
      emitProgress(step, TOTAL, 'Upload failed: ' + msg, 'error');
      updateSyncStatus({ lastError: msg });
      console.warn('[Parallel Cloud] cloudSave() failed:', msg);
      throw e;
    });
  }

  /* ─────────────────────────────────────────────────────────────────
     CLOUD LOAD — fetch workspace from Supabase + hydrate localStorage
     Must be preceded by explicit user confirmation (UI layer handles).
  ─────────────────────────────────────────────────────────────────── */

  function cloudLoad() {
    var c = client();
    if (!c) return Promise.reject(new Error('Supabase not configured'));

    var auth = global.ParallelAuth;
    if (!auth || !auth.isSignedIn) return Promise.reject(new Error('Not signed in'));

    var wsUuid = cloudWsId();
    if (!wsUuid) return Promise.reject(new Error('No cloud workspace ID found'));

    var tbl = T();

    emitProgress(0, 5, 'Backing up local data…', 'running');
    createLocalBackup();

    emitProgress(1, 5, 'Fetching workspace…', 'running');

    return Promise.all([
      c.from(tbl.workspaces).select('*').eq('id', wsUuid).maybeSingle(),
      c.from(tbl.databases).select('*').eq('workspace_id', wsUuid).is('deleted_at', null),
      c.from(tbl.records).select('*').eq('workspace_id', wsUuid).is('deleted_at', null),
      c.from(tbl.pages).select('*').eq('workspace_id', wsUuid).is('deleted_at', null),
      c.from(tbl.comments).select('*').eq('workspace_id', wsUuid),
      c.from(tbl.activity).select('*').eq('workspace_id', wsUuid).order('created_at', { ascending: true }),
    ])
    .then(function (results) {
      emitProgress(2, 5, 'Processing data…', 'running');
      var workspace  = results[0].data;
      var databases  = results[1].data || [];
      var records    = results[2].data || [];
      var pages      = results[3].data || [];
      var comments   = results[4].data || [];
      var activity   = results[5].data || [];

      if (!workspace) throw new Error('Cloud workspace not found');

      emitProgress(3, 5, 'Hydrating workspace…', 'running');
      hydrateFromCloud({ workspace, databases, records, pages, comments, activity });

      emitProgress(4, 5, 'Saving…', 'running');
      updateSyncStatus({
        lastDownloadAt: new Date().toISOString(),
        downloadCount:  (getSyncStatus().downloadCount || 0) + 1,
        lastError:      null,
      });

      emitProgress(5, 5, 'Load complete — reloading', 'done');
      console.info('[Parallel Cloud] cloudLoad() complete. Reloading…');
      setTimeout(function () { window.location.reload(); }, 800);
    })
    .catch(function (e) {
      var msg = e && e.message ? e.message : String(e);
      emitProgress(0, 5, 'Load failed: ' + msg, 'error');
      updateSyncStatus({ lastError: msg });
      console.warn('[Parallel Cloud] cloudLoad() failed:', msg);
      throw e;
    });
  }

  /* ─────────────────────────────────────────────────────────────────
     HYDRATE FROM CLOUD — convert Supabase rows back to local format
  ─────────────────────────────────────────────────────────────────── */

  function hydrateFromCloud(cloudData) {
    var ws         = cloudData.workspace;
    var databases  = cloudData.databases  || [];
    var records    = cloudData.records    || [];
    var pages      = cloudData.pages      || [];
    var comments   = cloudData.comments   || [];
    var activity   = cloudData.activity   || [];

    var idMap = getIdMap();

    // Build reverse ID maps: cloudUuid → localId (if we know it)
    var reversePages = {};
    var reverseDBs   = {};
    var reverseRecs  = {};
    Object.keys(idMap.pages).forEach(function (k) { reversePages[idMap.pages[k]] = k; });
    Object.keys(idMap.databases).forEach(function (k) { reverseDBs[idMap.databases[k]] = k; });
    Object.keys(idMap.records).forEach(function (k) { reverseRecs[idMap.records[k]] = k; });

    // Hydrate databases + their records
    var localDBs = databases.map(function (db) {
      var localId = reverseDBs[db.id] || ('db-cloud-' + db.id.slice(0, 8));
      idMap.databases[localId] = db.id;
      var dbRecords = records
        .filter(function (r) { return r.database_id === db.id; })
        .map(function (r) {
          var localRecId = reverseRecs[r.id] || ('rec-cloud-' + r.id.slice(0, 8));
          idMap.records[localRecId] = r.id;
          return {
            id:         localRecId,
            fields:     r.fields     || {},
            blocks:     r.blocks     || [],
            status:     r.status     || null,
            tags:       r.tags       || [],
            createdAt:  r.created_at || null,
            updatedAt:  r.updated_at || null,
            createdBy:  r.created_by || null,
            updatedBy:  r.updated_by || null,
          };
        });
      return {
        id:       localId,
        name:     db.name     || 'Untitled',
        icon:     db.icon     || null,
        color:    db.color    || null,
        fields:   db.fields   || [],
        views:    db.views    || [],
        settings: db.settings || {},
        records:  dbRecords,
      };
    });

    // Hydrate pages
    var localPages = pages.map(function (pg) {
      var localId = reversePages[pg.id] || ('pg-cloud-' + pg.id.slice(0, 8));
      idMap.pages[localId] = pg.id;
      var parentLocalId = pg.parent_id ? (reversePages[pg.parent_id] || null) : null;
      var meta = pg.metadata || {};
      return {
        id:        localId,
        title:     pg.title  || 'Untitled',
        icon:      pg.icon   || null,
        cover:     pg.cover  || null,
        parentId:  parentLocalId,
        blocks:    meta.blocks || [],
        metadata:  meta,
        createdAt: pg.created_at || null,
        updatedAt: pg.updated_at || null,
        createdBy: pg.created_by || null,
        updatedBy: pg.updated_by || null,
      };
    });

    // Hydrate comments
    var localComments = comments.map(function (c) {
      var localRecId = reverseRecs[c.entity_id] || null;
      var localPgId  = reversePages[c.entity_id] || null;
      return {
        id:         'comment-cloud-' + c.id.slice(0, 8),
        entityType: c.entity_type || 'record',
        entityId:   localRecId || localPgId || c.entity_id,
        body:       c.body        || '',
        authorId:   c.author_id   || null,
        isResolved: c.is_resolved || false,
        resolvedBy: c.resolved_by || null,
        createdAt:  c.created_at  || null,
        updatedAt:  c.updated_at  || null,
      };
    });

    // Hydrate activity events
    var localActivity = activity.map(function (ev) {
      return {
        id:         'act-cloud-' + ev.id.slice(0, 8),
        type:       ev.event_type  || 'unknown',
        entityType: ev.entity_type || null,
        entityId:   ev.entity_id   || null,
        actorId:    ev.actor_id    || null,
        payload:    ev.payload     || {},
        createdAt:  ev.created_at  || null,
      };
    });

    // Build local workspace snapshot
    var localWs = lsGet(WS_KEY) || {};
    var hydrated = Object.assign({}, localWs, {
      name:      ws.name     || localWs.name     || 'My Workspace',
      mode:      ws.mode     || localWs.mode     || 'personal',
      settings:  ws.settings || localWs.settings || {},
      databases: localDBs,
      pages:     localPages,
    });

    // Write back
    lsSet(WS_KEY, hydrated);
    lsSet(COMMENTS_KEY, localComments);
    lsSet(ACTIVITY_KEY, localActivity);
    saveIdMap(idMap);

    console.info('[Parallel Cloud] hydrateFromCloud() complete.',
      localDBs.length, 'databases,', localPages.length, 'pages,',
      localComments.length, 'comments,', localActivity.length, 'events.');
  }

  /* ── Public API ─────────────────────────────────────────────────── */
  var ParallelCloud = {
    getIdMap:          getIdMap,
    saveIdMap:         saveIdMap,
    getSyncStatus:     getSyncStatus,
    updateSyncStatus:  updateSyncStatus,
    createLocalBackup: createLocalBackup,
    resolveUserId:     resolveUserId,
    emitProgress:      emitProgress,
    cloudSave:         cloudSave,
    cloudLoad:         cloudLoad,
    hydrateFromCloud:  hydrateFromCloud,
  };

  global.ParallelCloud = ParallelCloud;

})(window);
